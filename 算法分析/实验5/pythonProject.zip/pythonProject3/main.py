from queue import Queue
class Map:
    def __init__(self):
        self.mat = [[0] * 100 for _ in range(100)]  # 初始化矩阵
        self.m = 0  # 矩阵行数
        self.n = 0  # 矩阵列数

    def setmap(self):
        for i in range(self.m + 2):
            for j in range(self.n + 2):
                self.mat[i][j] = 0
        for i in range(1, self.m + 1):
            row = list(map(int, input().split()))  # 输入每行的值
            for j in range(1, self.n + 1):
                self.mat[i][j] = row[j - 1]  # 将值存入矩阵中
    def BFS(self):
        x = 0
        y = 0
        qx = Queue()  # 存储 x 坐标的队列
        qy = Queue()  # 存储 y 坐标的队列
        qx.put(x)
        qy.put(y)
        self.mat[x][y] = 1
        xx = [-1, 0, 1, 0]  # x 坐标的增量，上右下左
        yy = [0, 1, 0, -1]  # y 坐标的增量，上右下左
        while not qx.empty():
            for i in range(4):
                if (0 <= qx.queue[0] + xx[i] <= self.m + 1 and
                        0 <= qy.queue[0] + yy[i] <= self.n + 1 and
                        self.mat[qx.queue[0] + xx[i]][qy.queue[0] + yy[i]] == 0):
                    # 判断下一个坐标是否在矩阵范围内且值为0（未访问过）
                    qx.put(qx.queue[0] + xx[i])  # 将新的 x 坐标入队
                    qy.put(qy.queue[0] + yy[i])  # 将新的 y 坐标入队
                    self.mat[qx.queue[0] + xx[i]][qy.queue[0] + yy[i]] = 1  # 标记新坐标已访问
            qx.get()  # 出队
            qy.get()  # 出队
    def print_area(self):
        count = 0
        for i in range(1, self.m + 1):
            for j in range(1, self.n + 1):
                if self.mat[i][j] == 0:
                    count += 1  # 统计未访问过的区域
        print("面积为:", count)
t = int(input("请输入测试用例的数量: "))
while t > 0:
    m = Map()
    m.m, m.n = map(int, input("请输入矩阵大小（空格分隔）: ").split())
    m.setmap()
    m.BFS()
    m.print_area()
t -= 1