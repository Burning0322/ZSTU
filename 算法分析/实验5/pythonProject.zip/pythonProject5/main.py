from collections import deque

def minimumTurns(n, m, terrain, start_row, start_col, target_row, target_col):
    directions = [(0, 1), (0, -1), (1, 0), (-1, 0)]  # 可行的四个方向：右、左、下、上

    queue = deque([(start_row, start_col, 0, -1)])  # 队列中的元素为：(当前行号，当前列号，拐弯次数，前一个方向索引)
    visited = set([(start_row, start_col, -1)])  # 记录已访问的位置和方向的组合

    while queue:
        row, col, turns, prev_direction = queue.popleft()

        if row == target_row and col == target_col:  # 到达目标位置
            return turns

        for i, (dx, dy) in enumerate(directions):
            new_row = row + dx
            new_col = col + dy

            if (0 <= new_row < n and 0 <= new_col < m and terrain[new_row][new_col] == 0 and
                    (new_row, new_col, i) not in visited):

                new_turns = turns
                if prev_direction != -1 and prev_direction != i:
                    new_turns += 1

                queue.append((new_row, new_col, new_turns, i))
                visited.add((new_row, new_col, i))

    return -1  # 无法到达目标位置

# 读取输入
n, m = map(int, input().split())
terrain = []
for _ in range(n):
    row = list(map(int, input().split()))
    terrain.append(row)
start_row, start_col, target_row, target_col = map(int, input().split())

# 计算最少的拐弯次数
result = minimumTurns(n, m, terrain, start_row - 1, start_col - 1, target_row - 1, target_col - 1)

# 输出结果
print(result)
