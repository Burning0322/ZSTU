import heapq

def dijkstra(graph, start):
    # 初始化距离数组
    distances = {node: float('inf') for node in graph}
    distances[start] = 0

    # 创建优先队列并将起始节点添加到队列中
    queue = [(0, start)]

    while queue:
        # 从队列中取出距离起始节点最近的节点
        current_distance, current_node = heapq.heappop(queue)

        # 如果当前节点已被处理，则跳过
        if current_distance > distances[current_node]:
            continue

        # 扩展当前节点的邻居节点
        for neighbor, weight in graph[current_node].items():
            distance = current_distance + weight

            # 如果通过当前节点到达邻居节点的距离更短，则更新最短距离
            if distance < distances[neighbor]:
                distances[neighbor] = distance
                heapq.heappush(queue, (distance, neighbor))

    return distances

# 从用户输入构建图形表示的邻接字典
graph = {}
num_nodes = int(input("输入图中节点的数量："))

for i in range(num_nodes):
    node = input(f"输入节点 {i+1} 的名称：")
    num_neighbors = int(input(f"输入与节点 {node} 相邻的节点数量："))

    neighbors = {}
    for j in range(num_neighbors):
        neighbor, weight = input(f"输入与节点 {node} 相邻的节点名称和权重（格式：邻居节点名称 权重）：").split()
        neighbors[neighbor] = int(weight)

    graph[node] = neighbors

start_node = input("输入起始节点的名称：")
shortest_distances = dijkstra(graph, start_node)

print(f"最短路径数组：{shortest_distances}")
