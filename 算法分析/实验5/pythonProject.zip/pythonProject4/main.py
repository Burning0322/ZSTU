from collections import deque


def shortest_distance(n, ocean_map, start_row, start_col, target_row, target_col):
    # 计算哥伦比亚号到铁塔尼号的最短距离

    # 创建一个队列用于广度优先搜索
    queue = deque()
    queue.append((start_row, start_col, 0))  # (行, 列, 距离)

    # 创建一个矩阵记录每个格子是否已访问过
    visited = [[False] * n for _ in range(n)]
    visited[start_row][start_col] = True

    # 定义四个方向的行和列的增量
    directions = [(-1, 0), (0, 1), (1, 0), (0, -1)]

    while queue:
        row, col, distance = queue.popleft()

        # 到达铁塔尼号的位置，返回距离
        if row == target_row and col == target_col:
            return distance

        # 尝试四个方向的移动
        for direction in directions:
            new_row = row + direction[0]
            new_col = col + direction[1]

            # 检查新位置是否在合法范围内，并且是海洋（值为0），且未被访问过
            if 0 <= new_row < n and 0 <= new_col < n and ocean_map[new_row][new_col] == '0' and not visited[new_row][new_col]:
                queue.append((new_row, new_col, distance + 1))
                visited[new_row][new_col] = True

    # 没有找到路径，返回-1
    return -1


# 读取输入
n = int(input())  # 输入海洋地图的大小
ocean_map = [input() for _ in range(n)]  # 输入海洋地图的每一行
start_row, start_col, target_row, target_col = map(int, input().split())  # 输入起点和终点的坐标

# 调用函数计算最短距离
distance = shortest_distance(n, ocean_map, start_row - 1, start_col - 1, target_row - 1, target_col - 1)

# 输出结果
print(distance)  # 输出最短距离
