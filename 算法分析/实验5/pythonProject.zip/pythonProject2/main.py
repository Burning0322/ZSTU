class Node:
    def __init__(self, level, weight, value, bound, includes):
        self.level = level  # 当前层级
        self.weight = weight  # 当前物品总重量
        self.value = value  # 当前物品总价值
        self.bound = bound  # 当前节点的上界
        self.includes = includes  # 当前物品的选择情况（包含/不包含）

def knapsack_branch_bound(weights, values, capacity):
    n = len(weights)  # 物品数量
    items = list(zip(weights, values))  # 将重量和价值打包成元组

    # 按照单位重量价值排序
    items.sort(key=lambda x: x[1] / x[0], reverse=True)

    # 初始化最优解
    best_value = 0
    best_selection = []

    # 创建初始节点
    root = Node(0, 0, 0, 0, [])

    # 创建候选节点集合，使用堆栈实现
    candidates = []
    candidates.append(root)

    while candidates:
        current = candidates.pop()

        # 如果当前节点的上界小于当前最优解，则丢弃该节点
        if current.bound < best_value:
            continue

        # 扩展节点
        if current.level < n:
            # 选择当前物品
            weight_with_item = current.weight + items[current.level][0]
            value_with_item = current.value + items[current.level][1]
            bound_with_item = current.bound
            includes_with_item = current.includes[:]  # 复制列表

            # 如果当前物品可以完全放入背包，则更新上界
            if weight_with_item <= capacity:
                bound_with_item = value_with_item
                includes_with_item.append(1)
                # 更新最优解
                if value_with_item > best_value:
                    best_value = value_with_item
                    best_selection = includes_with_item

            # 创建新节点表示选择当前物品
            node_with_item = Node(current.level + 1, weight_with_item, value_with_item, bound_with_item, includes_with_item)
            candidates.append(node_with_item)

            # 不选择当前物品
            bound_without_item = current.bound - items[current.level][1]
            includes_without_item = current.includes[:]  # 复制列表

            # 创建新节点表示不选择当前物品
            node_without_item = Node(current.level + 1, current.weight, current.value, bound_without_item, includes_without_item)
            candidates.append(node_without_item)

    return best_value, best_selection

# 用户输入物品重量、价值和背包容量
weights = list(map(int, input("请输入物品的重量（以空格分隔）: ").split()))
values = list(map(int, input("请输入物品的价值（以空格分隔）: ").split()))
capacity = int(input("请输入背包的容量: "))

best_value, best_selection = knapsack_branch_bound(weights, values, capacity)
print("最优解的总价值:", best_value)
print("最优解的物品选择情况:", best_selection)
