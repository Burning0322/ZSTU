def subset_sum(S, target):
    n = len(S)
    # 创建一个二维数组dp，用于记录子问题的解
    dp = [[False] * (target + 1) for _ in range(n + 1)]

    # 初始化边界条件
    for i in range(n + 1):
        dp[i][0] = True

    # 动态规划求解子问题
    for i in range(1, n + 1):   #从集合 S 的第一个元素开始遍历，同时从目标和 1 开始遍历
        for j in range(1, target + 1):
            if j < S[i - 1]:    #如果当前的目标和 j 小于当前元素 S[i-1]，则无法选择该元素，继承上一行的结果 dp[i-1][j]。
                dp[i][j] = dp[i - 1][j]
            else:   #否则，可以选择该元素或不选择该元素。如果选择该元素，则目标和减去当前元素，并继承上一行、上一列的结果 dp[i-1][j-S[i-1]]。
                dp[i][j] = dp[i - 1][j] or dp[i - 1][j - S[i - 1]]

    # 判断是否存在解，如果不存在则输出"No Solution!"
    if not dp[n][target]:
        return "No Solution!"

    # 构造解的具体内容
    subset = []
    i, j = n, target
    while i > 0 and j > 0:
        if dp[i - 1][j]:
            i -= 1
        else:
            subset.append(S[i - 1])
            j -= S[i - 1]
            i -= 1

    # 按字典序输出解
    subset.sort()
    return subset


# 读取输入
with open('subsum.in', 'r') as file:    #从文件中读取输入，文件名为 subsum.in。
    n, target = map(int, file.readline().split())
    S = list(map(int, file.readline().split()))

# 解决子集和问题
result = subset_sum(S, target)

# 输出结果
with open('subsum.out', 'w') as file:   #将结果输出到文件，文件名为 subsum.out。
    if result == "No Solution!":
        file.write(result)
    else:
        file.write(' '.join(map(str, result)))
