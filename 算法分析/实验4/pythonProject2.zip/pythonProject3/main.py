import math

def place(k, x):    #判断在第 k 行的皇后是否可以放置在列号为 x[k] 的位置上
    for i in range(1, k):
        if x[k] == x[i] or abs(k - i) == abs(x[k] - x[i]):
            return False
    return True

def queens(n):  #解决 n 皇后问题并打印所有解
    x = [0] * (n + 1)   #创建一个长度为 n+1 的列表 x，用于存储每一行皇后所在的列号
    i = 1   #初始化变量 i = 1，表示当前处理的是第 1 行
    x[i] = 0    #将 x[i] 的初始值设为 0
    while i >= 1:   #进入循环，当 i >= 1 时
        x[i] += 1
        while x[i] <= n and not place(i, x):    #在 x[i] 的范围内循环，直到找到一个可以放置皇后的位置或者超过最大列数 n
            x[i] += 1
        if x[i] <= n:   #如果 x[i] 小于等于 n，表示找到一个可以放置皇后的位置
            if i == n:  #如果 i 等于 n，说明已经找到一个完整的解，打印该解
                for k in range(1, n + 1):
                    print("{:5d}".format(x[k]), end='')
                print()
            else:   #否则，继续处理下一行，即 i 加 1，同时将 x[i] 的初始值设为 0
                i += 1
                x[i] = 0
        else:   #如果 x[i] 大于 n，表示在当前行无法找到合适的位置放置皇后，退回到上一行，即 i 减 1
            i -= 1

def queens_recursive(i, x, n):  #递归解决 n 皇后问题并打印所有解
    if i > n:   #参数 i 表示当前处理的行数，x 是一个列表，存储每一行皇后所在的列号，n 是总行数
        for k in range(1, n + 1):   #如果 i 大于 n，表示已经处理完最后一行，打印当前解
            print("{:5d}".format(x[k]), end='')
        print()
    else:
        for j in range(1, n + 1):
            x[i] = j
            if place(i, x):
                queens_recursive(i + 1, x, n)

# 主程序
if __name__ == "__main__":
    n = int(input("请输入皇后的数量："))
    x = [0] * (n + 1)
    queens(n)
    # queens_recursive(1, x, n)
