def combinations(n, r, start, comb):    #定义递归函数
    if r == 0:  #如果需要选择的元素个数 r 等于 0，表示已经选择完毕，打印当前组合中的元素
        print(" ".join(str(num) for num in comb))
    else:
        for i in range(start, n + 1):   #循环从 start 到 n，表示选择下一个元素
            comb.append(i)
            combinations(n, r - 1, i + 1, comb)
            comb.pop()

#在主程序中，从输入中获取 n 和 r
n, r = map(int, input("两个自然数:").split())
combinations(n, r, 1, [])
