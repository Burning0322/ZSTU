import sys
from itertools import permutations  #用于生成所有可能的排列组合

INF = float('inf')  #将其设置为正无穷大的浮点数


def tsp_backtracking(n, graph): #定义一个函数，该函数接受城市数量n和距离矩阵graph作为参数。
    bestw = INF #初始化

    for perm in permutations(range(n)): #使用permutations函数生成城市索引的所有可能排列组合，并将每个排列赋值给perm。
        path_len = sum(graph[perm[i]][perm[(i + 1) % n]] for i in range(n)) #计算当前排列perm的路径长度。通过迭代排列中的每个城市索引，使用graph距离矩阵查找相邻城市之间的距离，并将其累加到path_len中。
        bestw = min(bestw, path_len)    #比较当前路径长度path_len与bestw的值，将较小值赋给bestw，以保留最小路径长度。

    return bestw

#从用户输入中获取城市的数量，并将其转换为整数类型。
n = int(input("请输入城市的数量: "))
graph = []

print("请输入城市之间的距离或旅费矩阵:")
for _ in range(n):
    row = list(map(int, input().split()))   #将用户输入的一行数据转换为整数列表
    graph.append(row)   #将转换后的整数列表添加到graph列表中，构建距离或旅费矩阵。

bestw = tsp_backtracking(n, graph)  #传递城市数量n和距离矩阵graph作为参数，并将返回的最小路径长度赋值给bestw。

if bestw == INF:
    print("无可行的路径")
else:
    print("最小路程为:", bestw)
