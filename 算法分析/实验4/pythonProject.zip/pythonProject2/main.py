class Position:
    def __init__(self, row, col):   #初始化row和col
        self.row = row
        self.col = col

    def __str__(self):  #定义了字符串表示形式。
        return "(" + str(self.row) + ", " + str(self.col) + ")"


class Maze:
    def __init__(self): #初始化
        self.maze = [[0 for _ in range(15)] for _ in range(15)] #创建一个二位列表
        self.stack = [] #创建一个空列表
        self.p = [[False for _ in range(15)] for _ in range(15)]    #创建一个二位列表
        self.row = 0
        self.col = 0

    def init(self): #初始化迷宫的行数，列数和迷宫内容
        self.row = int(input("请输入迷宫的行数: ")) #用户输入设置迷宫的行数
        self.col = int(input("请输入迷宫的列数: ")) #用户输入设置迷宫的列数
        print("请输入", self.row, "行", self.col, "列的迷宫:")
        for i in range(self.row):   #循环迭代迷宫的行数次
            row_input = input().split()
            for j in range(self.col):
                self.maze[i][j] = int(row_input[j])

    def findPath(self): #定义一个寻找迷宫路径
        temp = [[1 for _ in range(self.col + 2)] for _ in range(self.row + 2)]  #创建一个二位列表，将所有元素初始化为1，赋值给temp

        for i in range(self.row):   #循环迭代迷宫的行数次
            for j in range(self.col):   #循环迭代迷宫的列数次
                temp[i + 1][j + 1] = self.maze[i][j]    #将迷宫的元素复制到temp中对应的位置

        i = 1
        j = 1
        self.p[i][j] = True #将迷宫起始位置标记为已访问
        self.stack.append(Position(i, j))   #将起始位置添加到栈中

        while self.stack and not (i == self.row and j == self.col): #当栈不为空且当前位置不是迷宫终点时循环执行。
            if temp[i][j + 1] == 0 and not self.p[i][j + 1]:    #如果右边的位置是可走的且未访问过。
                self.p[i][j + 1] = True #标记右边位置为已访问
                self.stack.append(Position(i, j + 1))   #将起始位置添加到栈中
                j += 1  #向右移动一列
            elif temp[i + 1][j] == 0 and not self.p[i + 1][j]:  #如果下方的位置是可走的且未访问过。
                self.p[i + 1][j] = True #标记下方位置为已访问。
                self.stack.append(Position(i + 1, j))   #将下方位置添加到栈中
                i += 1  #向下移动一行
            elif temp[i][j - 1] == 0 and not self.p[i][j - 1]:  #如果左边的位置是可走的且未访问过。
                self.p[i][j - 1] = True #标记左边位置为已访问
                self.stack.append(Position(i, j - 1))   #将左边位置添加到栈中。
                j -= 1  #向左移动一列。
            elif temp[i - 1][j] == 0 and not self.p[i - 1][j]:  #如果上方的位置是可走的且未访问过。
                self.p[i - 1][j] = True #将上方位置标记为已访问
                self.stack.append(Position(i - 1, j))   #将上方位置加入栈中
                i -= 1  #将当前位置向上移动一格
            else:
                self.stack.pop()   #从栈中弹出当前位置
                if not self.stack:  #如果栈为空，表示无法找到路径，跳出循环
                    break
                i = self.stack[-1].row
                j = self.stack[-1].col

        new_pos = []
        if not self.stack:  #如果栈为空，说明没有找到路径
            print("没有路径")
        else:
            print("有路径")
            print("路径如下:")
            while self.stack:   #从栈中弹出一个位置并将其添加到new_pos列表中
                pos = self.stack.pop()
                new_pos.append(pos)
        #创建一个新的result列表，用于存储迷宫的可视化表示
        result = [["" for _ in range(self.col)] for _ in range(self.row)]
        for k in range(self.row):
            for t in range(self.col):
                result[k][t] = str(self.maze[k][t])
        #当new_pos列表不为空时，循环执行以下操作
        while new_pos:
            p1 = new_pos.pop()  #从new_pos列表中弹出一个位置p1
            result[p1.row - 1][p1.col - 1] = "#"    #将迷宫中对应位置[p1.row - 1，p1.col - 1]的值设置为"#"，表示路径经过的位置
        #遍历result列表中的每个位置，并按行打印迷宫的可视化表示
        for k in range(self.row):
            for t in range(self.col):
                print(result[k][t], end="\t")
            print()


demo = Maze()
demo.init()
demo.findPath()
