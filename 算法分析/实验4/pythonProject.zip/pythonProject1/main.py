# 全局变量
maxValue = 0

# 回溯算法
def backtrack(index, currentWeight, currentValue):  #该函数用于搜索背包中物品的组合
    global maxValue

    if index == len(weights):   #如果已经遍历完所有物品（即达到了叶子节点）。
        maxValue = max(maxValue, currentValue)  #更新maxvalue为当前最大价值和当前计算的价值的较大值。
        return

    #如果当前物品的重量超过了背包的容量，或者当前物品的价值加上剩余物品的最大价值仍然小于等于maxvalue
    if currentWeight + weights[index] > capacity or currentValue + maxValues[index] <= maxValue:
        return

    if currentWeight + weights[index] <= capacity:  #如果当前物品的重量加上背包中已有物品的重量不超过背包的容量。
        backtrack(index + 1, currentWeight + weights[index], currentValue + values[index])  #选择当前物品放入背包,并递归继续搜索下一个物品

    backtrack(index + 1, currentWeight, currentValue)   #不选择当前物品放入背包，并递归调用函数backtrack函数继续搜索下一个物品


# 0-1背包问题求解函数
def knapsack_01():
    global maxValue

    maxValue = 0
    backtrack(0, 0, 0)
    return maxValue


# 用户输入相关参数
n = int(input("请输入物品数量: "))
weights = []
values = []
maxValues = []
capacity = int(input("请输入背包容量: "))

print("请依次输入每个物品的重量:")
weight_values = input().split()
for i in range(n):
    weight = int(weight_values[i])
    weights.append(weight)

print("请依次输入每个物品的价值:")
value_values = input().split()
for i in range(n):
    value = int(value_values[i])
    values.append(value)

print("请依次输入剩余物品的最大价值:")
max_value_values = input().split()
for i in range(n):
    max_value = int(max_value_values[i])
    maxValues.append(max_value)

# 调用函数求解
result = knapsack_01()
print("背包能容纳的最大价值为:", result)
