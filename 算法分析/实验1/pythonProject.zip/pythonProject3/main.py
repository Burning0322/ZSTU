#定义了print_chessboard函数，用于打印棋盘的当前状态。
# 通过格式化字符串打印出step和棋盘的字符串表示。
def print_chessboard(a, step):
    print('step{:2d}:{}'.format(step, ''.join(a)))
#定义了move函数，用于移动棋子的位置。
def move(a, k, sp, step):
    #通过交换元素的方式将棋子从位置k移动到sp+j的位置，同时将原来的位置置为'-'。
    for j in range(2):
        a[sp+j] = a[k+j-1]
        a[k+j-1] = '-'
    #调用print_chessboard函数打印移动后的棋盘状态。
    print_chessboard(a, step)
    #更新sp的值为k-1，并返回更新后的sp。
    sp = k - 1
    return sp

#定义了mv函数，用于递归移动棋子。
def mv(a, n, sp, step):
    #当n为4时，按照规定的移动顺序依次调用move函数移动棋子，并更新sp的值。
    if n == 4:
        sp = move(a, 4, sp, step)
        sp = move(a, 8, sp, step)
        sp = move(a, 2, sp, step)
        sp = move(a, 7, sp, step)
        sp = move(a, 1, sp, step)
    #当n不为4时，先调用move函数移动棋子，然后递归调用mv函数，将n减1，并更新step的值。
    else:
        sp = move(a, n, sp, step)
        sp = move(a, n*2-1, sp, step)
        sp = mv(a, n-1, sp, step+1)
    #返回更新后的sp。
    return sp

n = int(input("Please insert a number:"))
a = ['o' for _ in range(n)] + ['*' for _ in range(n)] + ['-', '-']
sp = 2 * n
print_chessboard(a, 0)
sp = mv(a, n, sp, 1)
