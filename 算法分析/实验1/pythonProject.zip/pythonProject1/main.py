# 归并排序函数
def merge_sort(arr):
    # 如果数组长度小于等于1，直接返回数组
    if len(arr) <= 1:
        return arr
    # 否则，将数组分为左右两部分，并对每部分进行递归调用归并排序函数
    mid = len(arr) // 2
    left = arr[:mid]
    right = arr[mid:]

    # 最后将左右两部分合并排序，调用merge函数实现
    left = merge_sort(left)
    right = merge_sort(right)
    return merge(left, right)

# 合并函数
def merge(left, right):
    # 初始化一个空列表 merged
    merged = []
    # 使用两个索引 left_index 和 right_index 分别追踪左右两部分的位置
    left_index = 0
    right_index = 0
    # 当左右两部分都有元素时，比较当前元素大小，将较小的元素添加到 merged 中，同时更新索引
    while left_index < len(left) and right_index < len(right):
        if left[left_index] <= right[right_index]:
            merged.append(left[left_index])
            left_index += 1
        else:
            merged.append(right[right_index])
            right_index += 1

    # 当其中一部分已经遍历完时，将剩余部分的元素依次添加到 merged 中
    while left_index < len(left):
        merged.append(left[left_index])
        left_index += 1

    while right_index < len(right):
        merged.append(right[right_index])
        right_index += 1
    # 返回合并后的有序列表 merged
    return merged


# 提示用户输入待排序的元素列表
input_str = input("请输入待排序的元素列表，以空格分隔: ")
arr = list(map(int, input_str.split()))

# 调用归并排序
sorted_arr = merge_sort(arr)

# 显示排序后的结果
print("排序后的结果:", sorted_arr)
