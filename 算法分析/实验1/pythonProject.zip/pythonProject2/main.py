def find_maximum_values(k):
    # 初始化m、n和max_sum的初始值
    m = 1
    n = 1
    max_sum = 2

    # 遍历i和j的取值范围
    for i in range(1, k+1):
        for j in range(1, k+1):
            # 判断条件：(j^2 - i*j - i^2)^2 = 1 并且 i^2 + j^2 > max_sum
            if pow((pow(j,2) - i*j - pow(i,2)),2) == 1 and pow(i,2) + pow(j,2) > max_sum:
                # 更新m、n和max_sum的值
                m = i
                n = j
                max_sum = pow(i,2) + pow(j,2)

    # 返回满足条件的m和n
    return m, n

# 提示用户输入k
k = int(input("请输入k的值："))

# 调用函数查找满足条件的m和n，并使m^2 + n^2的值最大
m, n = find_maximum_values(k)

# 显示结果
print("m =", m)
print("n =", n)
