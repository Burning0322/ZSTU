# 定义一个函数来找到当前权重最小的边
def find_min_edge(graph, mst, vertices):
    min_weight = float('inf')   # 初始化最小权重为无穷大
    min_edge = None

    for u in mst:   # 遍历最小生成树中的顶点和所有顶点集合
        for v in vertices:
            if v not in mst and graph[u][v] < min_weight:   # 如果顶点v不在最小生成树中，并且u到v的权重小于当前最小权重
                min_weight = graph[u][v]    # 更新最小权重
                min_edge = (u, v)   # 更新最小权重的边

    return min_edge

# 使用贪心算法构建最小生成树
def greedy_mst(graph):
    num_vertices = len(graph)
    mst = set()  # 最小生成树的顶点集合
    mst.add(0)  # 从第一个顶点开始构建最小生成树

    while len(mst) < num_vertices:
        # 找到当前权重最小的边
        edge = find_min_edge(graph, mst, range(num_vertices))
        u, v = edge

        # 将边的另一个顶点添加到最小生成树中
        mst.add(v)

    return mst

# 用户输入顶点数量
num_vertices = int(input("请输入顶点数量: "))

# 初始化邻接矩阵
graph = []
for i in range(num_vertices):
    row = list(map(int, input(f"请输入顶点{i}到其他顶点的权重，以空格分隔: ").split()))    # 用户输入顶点i到其他顶点的权重，以空格分隔
    graph.append(row)

# 使用贪心算法构建最小生成树
mst = greedy_mst(graph)

# 输出最小生成树的顶点集合
print("最小生成树的顶点集合：", mst)
