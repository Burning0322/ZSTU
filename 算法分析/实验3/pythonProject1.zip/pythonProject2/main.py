import sys

def dijkstra(n, v, c):
    # 初始化距离和已访问集合
    dist = [sys.maxsize] * (n + 1)  # 距离列表，初始值为无穷大
    prev = [0] * (n + 1)  # 前一个节点列表，初始值为0
    s = [False] * (n + 1)  # 已访问集合列表，初始值为False

    # 初始化源节点
    for i in range(1, n + 1):
        dist[i] = c[v][i]  # 源节点v到节点i的距离
        s[i] = False
        if dist[i] == sys.maxsize:
            prev[i] = 0
        else:
            prev[i] = v

    # 将源节点放入已访问集合
    dist[v] = 0
    s[v] = True

    # 循环将每个节点放入已访问集合
    for _ in range(1, n):
        temp = sys.maxsize
        u = v

        # 从未访问集合中找到dist最小的节点
        for j in range(1, n + 1):
            if not s[j] and dist[j] < temp:
                u = j
                temp = dist[j]

        s[u] = True

        # 更新通过u连接的未访问节点的dist值
        for j in range(1, n + 1):
            if not s[j] and c[u][j] < sys.maxsize:
                newdist = dist[u] + c[u][j]
                if newdist < dist[j]:
                    dist[j] = newdist
                    prev[j] = u

    return dist, prev

# 用户输入节点数量 n
n = int(input("请输入节点数量: "))

# 用户输入源节点 v
v = int(input("请输入源节点: "))

# 初始化邻接矩阵 c
c = []
for i in range(n):
    row = list(map(int, input(f"请输入节点{i+1}到其他节点的距离，以空格分隔: ").split()))
    c.append(row)

dist, prev = dijkstra(n, v, c)

print("从源节点到各节点的最短距离：")
for i in range(1, n + 1):
    print(f"节点 {i}: {dist[i]}")

print("各节点的前一个结点：")
for i in range(1, n + 1):
    print(f"节点 {i}: {prev[i]}")
