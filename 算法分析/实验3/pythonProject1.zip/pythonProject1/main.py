def find_change(n):
    denominations = [20, 10, 5, 1]  # 硬币面值列表
    result = []  # 存储找零的硬币

    for coin in denominations:  # 遍历硬币面值列表
        while n >= coin:    # 当金额大于等于当前硬币面值时，进行找零操作
            result.append(coin) # 将当前硬币加入找零结果列表
            n -= coin   # 减去当前硬币面值，更新剩余金额

    return result

amount = int(input("请输入需要找零的金额（单位：分）："))    # 用户输入需要找零的金额
change = find_change(amount)    # 调用函数进行找零操作
print("找零的最佳方案：", change)   # 输出找零的最佳方案
print("硬币数量：", len(change))     # 输出找零的硬币数量
