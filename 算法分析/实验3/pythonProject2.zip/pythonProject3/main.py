def remove_digits(N, S):
    stack = []  # 使用栈来存储剩下的数字

    # 从左到右遍历数字
    for digit in N:
        while S > 0 and stack and stack[-1] > digit:    #剩余删除次数S大于0，且栈非空，且栈元素大于当前数字的情况下            # 如果当前数字比栈顶元素小，则删除栈顶元素
            stack.pop() #移除栈顶元素
            S -= 1  #将剩余的删除次数S-1

        stack.append(digit)  # 将当前数字加入栈中

    # 如果还有剩余的删除次数，继续删除末尾的数字
    while S > 0 and stack:
        stack.pop()
        S -= 1

    # 构造最终的结果
    result = ''.join(stack)

    return result

# 测试样例
N = input("请输入N：")
S = int(input("请输入S："))
result = remove_digits(N, S)
print(result)
