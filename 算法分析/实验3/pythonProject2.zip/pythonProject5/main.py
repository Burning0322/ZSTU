import heapq

def merge_fruits(n, fruits):
    heapq.heapify(fruits)  # 将果子堆转化为最小堆

    total_cost = 0  # 总体力耗费值

    while len(fruits) > 1:
        # 从最小堆中取出两堆果子
        min1 = heapq.heappop(fruits)
        min2 = heapq.heappop(fruits)

        # 合并两堆果子，得到新堆
        new_heap = min1 + min2

        # 将新堆放入最小堆中
        heapq.heappush(fruits, new_heap)

        # 累加体力耗费值
        total_cost += new_heap

    return total_cost

# 输入果子种类数n和每种果子的数目
n = int(input("输入整数N："))
fruits = list(map(int, input("输入包含的整数：").split()))

# 调用函数计算最小的体力耗费值
min_cost = merge_fruits(n, fruits)
print("最小的体力耗费值:",min_cost)
