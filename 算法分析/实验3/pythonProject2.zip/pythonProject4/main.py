def intercept_missiles(heights):    #目的是计算拦截导弹所需的最小配备系统数。
    n = len(heights)    #获取输入heights的长度然后储在变量n中
    dp = [1] * n    #创建列表dp用于存储以每个导弹为结尾的最长递增子序列的长度。

    for i in range(1, n):   #从第二个到导弹开始到最后一个导弹
        for j in range(i):  #第一个导弹到当前最外层循环迭代的导弹
            if heights[i] <= heights[j]:    #检查当前导弹的高度是否小于等于前面某个导弹的高度
                dp[i] = max(dp[i], dp[j] + 1)   #更新dp[i]为前面的最大的递增子序列长度加一

    k = max(dp) #找到dp列表最大值，存入k中
    return k    #作为函数返回

# 输入导弹高度
heights = list(map(int, input("输入导弹高度：").split()))

# 反转导弹高度，转化为求最长递增子序列
reversed_heights = heights[::-1]

# 调用函数计算最小配备系统数k
k = intercept_missiles(reversed_heights)
print("导弹拦截系统K =", k)
