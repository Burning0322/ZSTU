def longest_common_subsequence(x,y):
    m=len(x)
    n=len(y)

    #创建一个二维数组并初始化为0
    dp=[[0]*(n+1)for _ in range (m+1)]

    #使用动态规划来填充数组
    for i in range(1,m+1):
        for j in range(1,n+1):
            if x[i-1]==y[j-1]:
                dp[i][j]=dp[i-1][j-1]+1
            else:
                dp[i][j]=max(dp[i-1][j],dp[i][j-1])

    #构造最长公共子序列
    lcs=[]
    i=m
    j=n
    while i>0 and j>0:
        if x[i-1]==y[j-1]:
            lcs.insert(0,x[i-1])
            i-=1
            j-=1
        elif dp[i-1][j]>dp[i][j-1]:
            i-=1
        else:
            j-=1
    return ''.join(lcs)

#让用户输入序列X和Y的值
x=input("请输入序列X的值：")
y=input("请输入序列Y的值：")

result= longest_common_subsequence(x,y)
print("最长公共子序列：",result)