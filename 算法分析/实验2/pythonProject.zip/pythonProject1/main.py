def allocate_equipment(N, M, profits):  #使用动态规划求解最大盈利
    dp = [[0] * (M + 1) for _ in range(N + 1)]  #创建一个二维数组，用于保存最大盈利
    for i in range(1, N + 1):   #使用动态规划填充数组
        for j in range(1, M + 1):   #遍历每个公司i和机器j的数量
            for k in range(j + 1):  #在j机器下，对于i公司遍历分配k台机器
                if profits[i][k] + dp[i - 1][j - k] > dp[i][j]: #如果分配k台机器的盈利加上前i-1个公司在剩余j-k台机器下的最大盈利大于当前最大盈利，更新最大盈利
                    dp[i][j] = profits[i][k] + dp[i - 1][j - k]

    # 回溯找出分配方案
    allocation = []
    i = N
    j = M
    while i > 0 and j > 0:  # 从dp[N][M]开始，逆向寻找最大盈利时的分配方案
        for k in range(j, 0, -1):   # 通过比较profits[i][k] + dp[i-1][j-k]与dp[i][j]的大小，确定分配机器k的数量
            if profits[i][k] + dp[i - 1][j - k] == dp[i][j]:
                allocation.append((i, k))
                i -= 1
                j -= k
                break

    # 反转分配方案并计算总盈利
    total_profit = dp[N][M]
    allocation.reverse()

    return total_profit, allocation # 返回总盈利和分配方案的元组


# 读取输入数据
N, M = map(int, input("请输入M和N：").split())
profits = [[0] * (M + 1) for _ in range(N + 1)] # 创建一个二维数组profits，用于保存每个公司在不同机器数量下的盈利
for i in range(1, N + 1):
    row = list(map(int, input("输入M*N的矩阵：").split()))    # 输入每个公司在不同机器数量下的盈利
    for j in range(1, M + 1):   # 将盈利值存储在profits数组中
        profits[i][j] = row[j - 1]

# 调用函数计算最大盈利和分配方案
max_profit, allocation = allocate_equipment(N, M, profits)

# 输出最大盈利
print(max_profit)

# 输出分配方案
for company, machines in allocation:
    print(company, machines)
