def minimum_weight(m, n, k, cylinders):
    # 创建一个二维数组dp，用于记录达到特定氧和氮量时的最小重量
    INF = float('inf')
    dp = [[INF] * (n + 1) for _ in range(m + 1)]    # 创建一个二维数组dp
    dp[0][0] = 0    #初始值为正无穷

    # 动态规划求解最小重量
    for c in cylinders:
        oxygen, nitrogen, weight = c
        for i in range(m, -1, -1):
            for j in range(n, -1, -1):  # 更新dp[i][j]，取当前值和通过加入当前气缸后的重量的较小值
                dp[i][j] = min(dp[i][j], dp[max(0, i - oxygen)][max(0, j - nitrogen)] + weight)

    return dp[m][n] # 返回达到目标氧量m和氮量n时的最小重量


# 读取输入数据
m, n = map(int, input("氧，氮各自的需要：").split())
k = int(input("气缸："))
cylinders = []
for _ in range(k):  # 输入每个气缸的氧量、氮量和重量，存储在cylinders列表中
    cylinder = list(map(int, input("气缸里的氧气和氮气的容量和气缸的重量：").split()))
    cylinders.append(cylinder)

# 调用函数计算最小重量
min_weight = minimum_weight(m, n, k, cylinders)

# 输出最小重量
print(min_weight)
