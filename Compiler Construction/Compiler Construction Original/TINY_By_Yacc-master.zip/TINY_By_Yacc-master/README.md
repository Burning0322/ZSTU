具体介绍

http://www.huangjihao.com/index.php/archives/505