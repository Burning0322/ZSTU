global_closure_num = 0
