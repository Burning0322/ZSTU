global_closure_num = 0
global_var_cnt = 0
global_label_cnt = 0
global_goto_label_stack = []  # 无条件跳转标签栈
global_if_goto_label_stack = []  # 条件跳转标签栈
global_while_label_stack = []
global_for_label_stack = []
global_for_operator_stack = []
