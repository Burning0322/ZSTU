from django.shortcuts import render,redirect,HttpResponse
from .models import User
# Create your views here.
def index(request):
    return render(request,'index.html')

def indexpage(request):
    return render(request,'indexpage.html')
def login(request):
    if request.method=='GET':
        return render(request,'login.html')
    if request.method=='POST':
        username=request.POST.get('username')
        password=request.POST.get('password')
        try:
            user=User.objects.get(username=username)
            if password==user.password:
                return render(request,'indexuser.html')
            else:
                return render(request,'login.html')
        except:
            return render(request,'login.html')

def indexuser(request):
    return render(request,'indexuser.html')

def register(request):
    if request.method=='POST':
        user=request.POST.get('username')
        password=request.POST.get('password')
        user_list = User.objects.filter(username=user)
        if user_list:
            return render(request, 'login.html')
        else:
            user=User.objects.create(username=user,password=password)
            user.save()
        return redirect('login.html')
    return render(request,'register.html')

def edit(request):
    edit_id=request.POST.get('id')
    edit_obj=User.objects.filter(id=edit_id).first()
    if request.method=='POST':
        username=request.POST.get('username')
        password=request.POST.get('password')
        User.objects.filter(id=edit_id).update(username=username,password=password)
        return render(request,'login.html')
    return render(request,'edit.html')

def delete_user(request):
    delete_id=request.GET.get('id')
    user=User.objects.filter(id=delete_id).delete()
    return render(request,'index.html')

def logout(request):
    return render(request,'index.html')