document.addEventListener("DOMContentLoaded", function () {
    // 获取图片元素和容器
    var images = document.querySelectorAll(".body_top img");
    var container = document.querySelector(".body_top");

    // 设置初始索引和切换时间
    var currentIndex = 0;
    var intervalTime = 3000; // 3秒

    // 显示第一张图片
    images[currentIndex].style.display = "block";

    // 定时切换图片
    setInterval(function () {
        // 隐藏当前图片
        images[currentIndex].style.display = "none";

        // 增加索引，确保在范围内
        currentIndex = (currentIndex + 1) % images.length;

        // 显示下一张图片
        images[currentIndex].style.display = "block";
    }, intervalTime);
});
