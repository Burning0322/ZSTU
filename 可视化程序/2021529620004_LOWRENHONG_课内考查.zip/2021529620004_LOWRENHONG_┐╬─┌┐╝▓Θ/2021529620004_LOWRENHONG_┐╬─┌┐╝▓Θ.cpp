﻿// 2021529620004_LOWRENHONG_课内考查.cpp : 定义应用程序的入口点。
//

#include "framework.h"
#include "2021529620004_LOWRENHONG_课内考查.h"

#define MAX_LOADSTRING 100

// 全局变量:
HINSTANCE hInst;                                // 当前实例
WCHAR szTitle[MAX_LOADSTRING];                  // 标题栏文本
WCHAR szWindowClass[MAX_LOADSTRING];            // 主窗口类名
static int Paint = 0;

// 此代码模块中包含的函数的前向声明:
ATOM                MyRegisterClass(HINSTANCE hInstance);
BOOL                InitInstance(HINSTANCE, int);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    About(HWND, UINT, WPARAM, LPARAM);

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPWSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    // TODO: 在此处放置代码。

    // 初始化全局字符串
    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_MY2021529620004LOWRENHONG, szWindowClass, MAX_LOADSTRING);
    MyRegisterClass(hInstance);

    // 执行应用程序初始化:
    if (!InitInstance (hInstance, nCmdShow))
    {
        return FALSE;
    }

    HACCEL hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_MY2021529620004LOWRENHONG));

    MSG msg;

    // 主消息循环:
    while (GetMessage(&msg, nullptr, 0, 0))
    {
        if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    return (int) msg.wParam;
}



//
//  函数: MyRegisterClass()
//
//  目标: 注册窗口类。
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex;

    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style          = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc    = WndProc;
    wcex.cbClsExtra     = 0;
    wcex.cbWndExtra     = 0;
    wcex.hInstance      = hInstance;
    wcex.hIcon          = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_MY2021529620004LOWRENHONG));
    wcex.hCursor = LoadCursorFromFile(L"2021529620004_LOWRENHONG_课内考查.cur");
    wcex.hbrBackground  = (HBRUSH)(COLOR_WINDOW+1);
    wcex.lpszMenuName   = MAKEINTRESOURCEW(IDC_MY2021529620004LOWRENHONG);
    wcex.lpszClassName  = szWindowClass;
    wcex.hIconSm        = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

    return RegisterClassExW(&wcex);
}

//
//   函数: InitInstance(HINSTANCE, int)
//
//   目标: 保存实例句柄并创建主窗口
//
//   注释:
//
//        在此函数中，我们在全局变量中保存实例句柄并
//        创建和显示主程序窗口。
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   hInst = hInstance; // 将实例句柄存储在全局变量中

   HWND hWnd = CreateWindowW(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, nullptr, nullptr, hInstance, nullptr);

   if (!hWnd)
   {
      return FALSE;
   }

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}

//
//  函数: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  目标: 处理主窗口的消息。
//
//  WM_COMMAND  - 处理应用程序菜单
//  WM_PAINT    - 绘制主窗口
//  WM_DESTROY  - 发送退出消息并返回
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    HPEN hP;
    HBRUSH hB;
    HDC hDC;
    PAINTSTRUCT PtStr;
    HMENU Menu;
    static HMENU hadmenu;

    switch (message)
    {
    case WM_COMMAND:
        {
            int wmId = LOWORD(wParam);
            // 分析菜单选择:
            switch (wmId)
            {
            case IDM_ABOUT:
                DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
                break;
            case IDM_EXIT:
                DestroyWindow(hWnd);
                break;
            case IDM_PAINT://“绘图”
                Paint = 1;
                InvalidateRect(hWnd, NULL, 1);
                break;
            case IDM_OPEN://“创建”
                Menu = GetMenu(hWnd);
                EnableMenuItem(Menu, IDM_OPEN, MF_BYCOMMAND | MF_GRAYED);//“创建”选择项不可用
                //新建弹出式菜单
                hadmenu = CreateMenu();
                AppendMenu(hadmenu, MF_POPUP, IDM_PAINT, L"绘图");
                InsertMenu(Menu, 3, MF_POPUP | MF_BYPOSITION, (UINT)hadmenu, L"编辑");
                DrawMenuBar(hWnd);
                break;

            case IDM_DELETE://“删除”
                Menu = GetMenu(hWnd);
                DeleteMenu(Menu, (UINT)hadmenu, MF_BYCOMMAND);//删除“编辑”选项    
                EnableMenuItem(Menu, IDM_DELETE, MF_BYCOMMAND | MF_GRAYED);//“删除”不可用
                DrawMenuBar(hWnd);
                break;
            default:
                return DefWindowProc(hWnd, message, wParam, lParam);
            }
        }
        break;
    case WM_PAINT:
        {
            /*PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hWnd, &ps);*/
            // TODO: 在此处添加使用 hdc 的任何绘图代码...
            //EndPaint(hWnd, &ps);
        hDC = BeginPaint(hWnd, &PtStr); 	//开始绘画
        SetMapMode(hDC, MM_TEXT);

        if (Paint == 1)//点击“绘图”
        {
            //画圆角矩形
            hP = CreatePen(PS_DASHDOT, 2, RGB(0, 0, 0));
            SelectObject(hDC, hP);
            hB = CreateHatchBrush(HS_CROSS, RGB(255, 0, 0));
            RoundRect(hDC, 400, 40, 500, 160, 10, 10);
            //黑色填充画刷画椭圆
            hB = (HBRUSH)GetStockObject(BLACK_BRUSH);
            SelectObject(hDC, hB);
            Ellipse(hDC, 400, 50, 500, 150);
        }
        //画右半边红色矩形
        hB = (HBRUSH)GetStockObject(DC_BRUSH);
        SetDCBrushColor(hDC, RGB(255, 0, 0));
        SelectObject(hDC, hB);
        Rectangle(hDC, 650, 80, 700, 150);

        //画左半边网格填充
        hB = CreateHatchBrush(HS_CROSS, RGB(255, 0, 0));
        SelectObject(hDC, hB);
        RoundRect(hDC, 120, 10, 200, 70, 10, 10);
        Pie(hDC, 120, 70, 200, 160, 150, 70, 170, 70);
        Rectangle(hDC, 120, 160, 200, 220);
        //蓝色描边
        hP = CreatePen(PS_DASHDOT, 2, RGB(0, 30, 250));
        SelectObject(hDC, hP);
        RoundRect(hDC, 120, 10, 200, 70, 10, 10);
        Pie(hDC, 120, 70, 200, 160, 150, 70, 170, 70);
        Rectangle(hDC, 120, 160, 200, 220);
        //删除画笔画刷
        DeleteObject(hB);
        DeleteObject(hP);
        EndPaint(hWnd, &PtStr);
        return 0;
        }
        break;
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

// “关于”框的消息处理程序。
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
        return (INT_PTR)TRUE;

    case WM_COMMAND:
        if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
        {
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        break;
    }
    return (INT_PTR)FALSE;
}
