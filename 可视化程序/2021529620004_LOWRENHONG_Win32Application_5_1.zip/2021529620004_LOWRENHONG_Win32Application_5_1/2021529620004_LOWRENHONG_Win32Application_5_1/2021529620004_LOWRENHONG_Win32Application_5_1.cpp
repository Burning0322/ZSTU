#include<windows.h>
#include<tchar.h>

BOOLEAN InitWindowClass(HINSTANCE hInstance, int nCmdShow);
LRESULT CALLBACK WINAPI WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	MSG msg;
	if (!InitWindowClass(hInstance, nCmdShow))
	{
		MessageBox(NULL, "��������ʧ�ܣ�", ("��������"), NULL);
		return 1;
	}
	while (GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return(int)msg.wParam;
}

LRESULT CALLBACK WINAPI WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	HDC hDC;						//�����豸�������
	PAINTSTRUCT ps;			//���������ͼ��Ϣ�Ľṹ�����
	HPEN hPen;				//���廭�ʾ��
	HBRUSH hBrush;			//���廭ˢ���
	static char cUp[] = "You had pressed the UP key";
	static char cCtrl[] = "You had pressed the Ctrl key";
	static char cShift[] = "You had pressed the SHIFT key";
	static char cCtrl_A[] = "You had pressed the CTRL A key";
	static char cShift_B[] = "You had pressed the SHIFT B key";
	static BOOL nUpKeyDown = FALSE, nShiftKeyDown = FALSE,
		nCtrlKeyDown = FALSE;
	static BOOL nCtrlAKeyDown = FALSE, nShiftBKeyDown = FALSE;
	switch (iMessage)
	{
	case WM_KEYDOWN:
	{ switch (wParam)
	{
	case VK_UP:			//�����ϼ�ͷ��ʱ��������Ϊ��
		nUpKeyDown = TRUE;
		break;
	case VK_SHIFT:		//����shift��ʱ��������Ϊ��
		nShiftKeyDown = TRUE;
		nShiftBKeyDown = FALSE;
		break;
	case VK_CONTROL:		//����control��ʱ��������Ϊ��
		nCtrlKeyDown = TRUE;
		nCtrlAKeyDown = FALSE;
		break;
	default:
		break;
	}
	}
	break;
	case WM_KEYUP:
		InvalidateRect(hWnd, NULL, FALSE);	//ˢ���û���
		break;
	case WM_CHAR:
		if (wParam == 1)
		{
			if (nCtrlKeyDown == TRUE)
			{
				nCtrlAKeyDown = TRUE;
				nCtrlKeyDown = FALSE;
			}
		}
		else if (wParam == 98 || wParam == 66)	//������b��ʱ
		{
			if (nShiftKeyDown == TRUE) //���shift���Ƿ��ڰ���״̬
			{
				nShiftBKeyDown = TRUE; //��SHIFT������ʱ��������Ϊ��
				nShiftKeyDown = FALSE;
			}
		}
		else;
		break;
	case WM_PAINT:					//������ͼ��Ϣ
		hDC = BeginPaint(hWnd, &ps);
		hBrush = (HBRUSH)GetStockObject(WHITE_BRUSH);
		hPen = (HPEN)GetStockObject(WHITE_PEN);
		SelectObject(hDC, hPen);
		SelectObject(hDC, hBrush);
		SetTextColor(hDC, RGB(255, 0, 0));		//����������ɫΪ��ɫ
		if (nUpKeyDown == TRUE)		 //�����Ϣ��
		{
			Rectangle(hDC, 0, 0, 300, 200);
			TextOut(hDC, 0, 0, cUp, strlen(cUp));
			nUpKeyDown = FALSE;
		}
		else if (nCtrlAKeyDown == TRUE)
		{
			Rectangle(hDC, 0, 0, 300, 200);
			TextOut(hDC, 0, 100, cCtrl_A, strlen(cCtrl_A));
			nCtrlAKeyDown = FALSE;
			nCtrlKeyDown = FALSE;
		}
		else if ((nCtrlKeyDown == TRUE) && (nCtrlAKeyDown == FALSE))
		{
			Rectangle(hDC, 0, 0, 300, 200);
			TextOut(hDC, 0, 60, cCtrl, strlen(cCtrl));
			nCtrlKeyDown = FALSE;
		}
		else if (nShiftBKeyDown == TRUE)
		{
			Rectangle(hDC, 0, 0, 300, 200);
			TextOut(hDC, 0, 0, cShift_B, strlen(cShift_B));
			nShiftBKeyDown = FALSE;
			nShiftKeyDown = FALSE;
		}
		else if ((nShiftKeyDown == TRUE) && (nShiftBKeyDown == FALSE))
		{
			Rectangle(hDC, 0, 0, 300, 200);
			TextOut(hDC, 0, 0, cShift, strlen(cShift));
			nShiftKeyDown = FALSE;
		}
		else;
		DeleteObject(hPen);				//ɾ�����ʺͻ�ˢ
		DeleteObject(hBrush);
		EndPaint(hWnd, &ps);
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	default:
		return(DefWindowProc(hWnd, iMessage, wParam, lParam));
	}
	return 0;
}

BOOLEAN InitWindowClass(HINSTANCE hInstance, int nCmdShow)
{
	WNDCLASSEX wcex;
	HWND hWnd;
	TCHAR szWindowClass[] = "����ʾ��";
	TCHAR szTitle[] = "2021529620004_LOWRENHONG_Win32Application_5_1";
	wcex.cbSize = sizeof(WNDCLASSEX);
	wcex.style = 0;
	wcex.lpfnWndProc = WndProc;
	wcex.cbClsExtra = 0;
	wcex.cbWndExtra = 0;
	wcex.hInstance = hInstance;
	wcex.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_APPLICATION));
	wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wcex.lpszMenuName = NULL;
	wcex.lpszClassName = szWindowClass;
	wcex.hIconSm = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_APPLICATION));
	if (!RegisterClassEx(&wcex))
		return FALSE;
	hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, NULL, NULL, hInstance, NULL);
	if (!hWnd)
		return FALSE;
	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);
	return TRUE;

}