﻿// 2021529620004_LOWRENHONG_第六周_星期四_实验二.cpp : 定义应用程序的入口点。
//

#include "framework.h"
#include "2021529620004_LOWRENHONG_第六周_星期四_实验二.h"

#define MAX_LOADSTRING 100

// 全局变量:
HINSTANCE hInst;                                // 当前实例
WCHAR szTitle[MAX_LOADSTRING];                  // 标题栏文本
WCHAR szWindowClass[MAX_LOADSTRING];            // 主窗口类名

// 此代码模块中包含的函数的前向声明:
ATOM                MyRegisterClass(HINSTANCE hInstance);
BOOL                InitInstance(HINSTANCE, int);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    About(HWND, UINT, WPARAM, LPARAM);

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
    _In_opt_ HINSTANCE hPrevInstance,
    _In_ LPWSTR    lpCmdLine,
    _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    // TODO: 在此处放置代码。

    // 初始化全局字符串
    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_MY2021529620004LOWRENHONG, szWindowClass, MAX_LOADSTRING);
    MyRegisterClass(hInstance);

    // 执行应用程序初始化:
    if (!InitInstance(hInstance, nCmdShow))
    {
        return FALSE;
    }

    HACCEL hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_MY2021529620004LOWRENHONG));

    MSG msg;

    // 主消息循环:
    while (GetMessage(&msg, nullptr, 0, 0))
    {
        if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    return (int)msg.wParam;
}

//
//  函数: MyRegisterClass()
//
//  目标: 注册窗口类。
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex;

    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style          = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc    = WndProc;
    wcex.cbClsExtra     = 0;
    wcex.cbWndExtra     = 0;
    wcex.hInstance      = hInstance;
    wcex.hIcon          = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_MY2021529620004LOWRENHONG));
    wcex.hCursor = LoadCursorFromFile(L"Cursor1.cur");
    wcex.hbrBackground  = (HBRUSH)(COLOR_WINDOW+1);
    wcex.lpszMenuName   = MAKEINTRESOURCEW(IDC_MY2021529620004LOWRENHONG);
    wcex.lpszClassName  = szWindowClass;
    wcex.hIconSm        = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

    return RegisterClassExW(&wcex);
}

//
//   函数: InitInstance(HINSTANCE, int)
//
//   目标: 保存实例句柄并创建主窗口
//
//   注释:
//
//        在此函数中，我们在全局变量中保存实例句柄并
//        创建和显示主程序窗口。
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   hInst = hInstance; // 将实例句柄存储在全局变量中

   HWND hWnd = CreateWindowW(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, nullptr, nullptr, hInstance, nullptr);

   if (!hWnd)
   {
      return FALSE;
   }

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}

//
//  函数: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  目标: 处理主窗口的消息。
//
//  WM_COMMAND  - 处理应用程序菜单
//  WM_PAINT    - 绘制主窗口
//  WM_DESTROY  - 发送退出消息并返回
//
//
bool popMenuEnable = false;
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    HMENU hMenu;
    HMENU topMenu = GetMenu(hWnd);
    HMENU subMenu;
    switch (message)
    {
    case WM_COMMAND:
    {
        int wmId = LOWORD(wParam);
        PAINTSTRUCT ps;
        HDC hDC = BeginPaint(hWnd, &ps);
        HPEN hPen;
        HBRUSH hBrush, hBrush1;
        // Parse the menu selections:
        switch (wmId)
        {
        case IDM_PAINT:
            hPen = CreatePen(PS_DASHDOT, 1, RGB(0, 255, 0));//自定义绿笔
            //所画线条为点划线，宽度为1
            hBrush = CreateHatchBrush(HS_CROSS, RGB(255, 0, 0));//红色网状
            hBrush1 = CreateSolidBrush(RGB(255, 0, 0)); //红色画刷
            SelectObject(hDC, hBrush);
            RoundRect(hDC, 213, 100, 287, 137, 20, 20);  //画一个圆角长方形
            Pie(hDC, 213, 137, 288, 212, 240, 137, 260, 137); 	//画一个圆饼
            Rectangle(hDC, 213, 212, 287, 250);           	//画一个长方形
            SelectObject(hDC, hPen);
            SelectObject(hDC, hBrush1);
            MoveToEx(hDC, 185, 178, NULL);
            LineTo(hDC, 315, 178);
            MoveToEx(hDC, 250, 80, NULL);
            LineTo(hDC, 250, 270);
            Rectangle(hDC, 400, 100, 500, 200);	//绘制矩形，并填充
            EndPaint(hWnd, &ps);
            DeleteObject(hPen);
            DeleteObject(hBrush);
            DeleteObject(hBrush1);
            break;
        case IDM_ADDCAL:
            subMenu = GetSubMenu(topMenu, 1);
            InsertMenu(subMenu, 1, MF_BYPOSITION, 40019, L"计算平均值");
            break;
        case IDM_MOVECAL:
            subMenu = GetSubMenu(topMenu, 1);
            ModifyMenu(subMenu, 1, MF_BYPOSITION | MF_STRING, 32778, L"线性拟合");
            break;
        case IDM_ABOUT:
            DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
            break;
        case IDM_EXIT:
            DestroyWindow(hWnd);
            break;
        default:
            return DefWindowProc(hWnd, message, wParam, lParam);
        }
    }
    break;
    case WM_RBUTTONDOWN:
        popMenuEnable = !popMenuEnable;
        break;
    case WM_LBUTTONDOWN:
        hMenu = CreatePopupMenu();
        AppendMenu(hMenu, MF_STRING, 50001, L"删除计算总和");
        AppendMenu(hMenu, MF_STRING, 50002, L"添加计算平均值");
        AppendMenu(hMenu, MF_STRING, 50003, L"修改计算均方差");

        if (!popMenuEnable) {
            EnableMenuItem(hMenu, 50001, MF_BYCOMMAND | MF_GRAYED);
            EnableMenuItem(hMenu, 50002, MF_BYCOMMAND | MF_GRAYED);
            EnableMenuItem(hMenu, 50003, MF_BYCOMMAND | MF_GRAYED);
        }
        POINT pt;
        GetCursorPos(&pt);
        TrackPopupMenu(hMenu, TPM_LEFTALIGN, pt.x, pt.y, 0, hWnd, NULL);
        break;
    case WM_PAINT:
    {
        /*PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hWnd, &ps);
        // TODO: Add any drawing code that uses hdc here...
        EndPaint(hWnd, &ps);*/
    }
    break;
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

// “关于”框的消息处理程序。
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
        return (INT_PTR)TRUE;

    case WM_COMMAND:
        if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
        {
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        break;
    }
    return (INT_PTR)FALSE;
}
