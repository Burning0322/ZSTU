﻿#include<windows.h>
#include<tchar.h>

//BOOLEAN InitWindowClass(HINSTANCE hInstance, int nCmdShow);
BOOL InitWindows(HINSTANCE hInstance, int nCmdShow);
BOOL InitWindowsClass(HINSTANCE hInstance);
LRESULT CALLBACK WINAPI WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);
HWND hWndMain;
HDC hDC;
HDC hdcmem;
HBITMAP hBm;
BITMAP bm;
int iy = 80;
int iWindowWidth, iWindowHeight;
char cUpWarn[] = "不能再向上移动了";
char cDownWarn[] = "不能再向下移动了";
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
    MSG msg;
    hBm = LoadBitmap(hInstance, "pic 6");
    GetObject(hBm, sizeof(BITMAP), (LPVOID)&bm);
    iWindowWidth = 2 * bm.bmWidth;
    iWindowHeight = 2 * bm.bmHeight;
    if (!InitWindowsClass(hInstance))
        return FALSE;
    if (!InitWindows(hInstance, nCmdShow))
        return FALSE;
    while (GetMessage(&msg, NULL, 0, 0))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    return(int)msg.wParam;
}

LRESULT CALLBACK WINAPI WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
    PAINTSTRUCT ps;
    switch (iMessage)
    {
    case WM_LBUTTONDOWN:
        iy = iy - 10;
        InvalidateRect(hWnd, NULL, 1);
        break;
    case WM_RBUTTONDOWN:
        iy = iy + 10;
        InvalidateRect(hWnd, NULL, 1);
        break;
    case WM_KEYDOWN:
        switch (wParam)
        {
        case VK_UP:
            iy = iy - 10;
            break;
        case VK_DOWN:
            iy = iy + 10;
            break;
        }
        InvalidateRect(hWnd, NULL, 1);
        break;
    case WM_CREATE:
        hDC = GetDC(hWnd);
        hdcmem = CreateCompatibleDC(hDC);
        ReleaseDC(hWnd, hDC);
    case WM_PAINT:
        hDC = BeginPaint(hWnd, &ps);
        if (iy > 0 && iy < iWindowHeight / 2)
        {
            SelectObject(hdcmem, hBm);
            BitBlt(hDC, 60, iy, bm.bmWidth, bm.bmHeight, hdcmem, 0, 0, SRCCOPY);
        }
        else if (iy <= 0)
            TextOut(hDC, 0, 0, cUpWarn, strlen(cUpWarn));
        EndPaint(hWnd, &ps);
        break;
    case WM_DESTROY:
        DeleteObject(hBm);
        PostQuitMessage(0);
        return 0;
    default:
        return(DefWindowProcA(hWnd, iMessage, wParam, lParam));
    }
    return 0;
}


BOOL InitWindows(HINSTANCE hInstance, int nCmdShow) // 初始化窗口
{
    HWND hWnd;
    hWnd = CreateWindow("Bitmap", "2021529620004_LOWRENHONG_Win32Application_7_2", WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL); // 生成窗口
    if (!hWnd)
        return FALSE;
    hWndMain = hWnd;
    ShowWindow(hWnd, nCmdShow);	//显示窗口
    UpdateWindow(hWnd);
    return TRUE;
}

BOOL InitWindowsClass(HINSTANCE hInstance)	//定义窗口类
{
    WNDCLASS WndClass;
    WndClass.cbClsExtra = 0;
    WndClass.cbWndExtra = 0;
    WndClass.hbrBackground = (HBRUSH)(GetStockObject(WHITE_BRUSH));
    WndClass.hCursor = LoadCursor(NULL, MAKEINTRESOURCE(IDC_ARROW));
    WndClass.hIcon = LoadIcon(NULL, MAKEINTRESOURCE(IDI_APPLICATION));
    WndClass.hInstance = hInstance;
    WndClass.lpfnWndProc = WndProc;
    WndClass.lpszClassName = "Bitmap";
    WndClass.lpszMenuName = "Menu";
    WndClass.style = 0;
    return RegisterClass(&WndClass);
}
