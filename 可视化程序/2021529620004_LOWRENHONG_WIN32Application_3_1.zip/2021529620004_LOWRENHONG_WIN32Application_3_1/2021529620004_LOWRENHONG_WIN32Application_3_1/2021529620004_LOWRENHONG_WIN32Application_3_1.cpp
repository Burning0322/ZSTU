#include<windows.h>
#include<tchar.h>
BOOLEAN InitWindowClass(HINSTANCE hInstancem, int nCmdShow);
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInst, LPSTR lpszCmdLine, int nCmdShow)
{
	MSG msg;
	if (!InitWindowClass(hInstance, nCmdShow))
	{
		MessageBox(NULL, "��������ʧ�ܣ�", "��������", NULL);
		return 1;
	}
	while (GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return msg.wParam;
}
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	HDC hDC;
	PAINTSTRUCT PtStr;
	HBRUSH hBrush;
	HPEN hPen;
	static int dispMode = -1;
	LPCTSTR str;
	switch (message)
	{
	case WM_LBUTTONDOWN:
		InvalidateRect(hWnd, NULL, TRUE);
		break;
	case WM_PAINT:
		hDC = BeginPaint(hWnd, &PtStr);
		dispMode = (dispMode + 1) % 6;
		switch (dispMode)
		{
		case0:
			str = _T("ӳ�䷽ʽMM_TEXT:ȱʡ��ӳ�䷽ʽ:");
			SetMapMode(hDC, MM_TEXT);
			TextOut(hDC, 0, 0, str, _tcsclen(str));
			break;
		case1:
			str = _T("ӳ�䷽ʽ MM_ISOTROPIC:��������Ϊ20*20��ӳ��Ϊ�ӿڳߴ�Ϊ10*10��ͼ����С1��");
			SetMapMode(hDC, MM_ISOTROPIC);
			SetWindowExtEx(hDC, 20, 20, NULL);
			SetViewportExtEx(hDC, 10, 10, NULL);
			TextOut(hDC, 0, 0, str, _tcsclen(str));
			break;
		case2:
			str = _T("ӳ�䷽ʽMM_ISOTROPIC:��������Ϊ10*10,ӳ��Ϊ�ӿڳߴ�Ϊ20*20��ͼ�ηŴ�Ϊ1��");
			SetMapMode(hDC, MM_ISOTROPIC);
			SetWindowExtEx(hDC, 10, 10, NULL);
			SetViewportExtEx(hDC, 20, 20, NULL);
			TextOut(hDC, 0, 0, str, _tcsclen(str));
			break;
		case3:
			str = _T("ӳ�䷽ʽMM_ANISOTROPIC:��������Ϊ10*10.ӳ��Ϊ�ӿڳߴ�Ϊ20*10��ͼ�κ���Ŵ�һ�������򲻱�");
			SetMapMode(hDC, MM_ISOTROPIC);
			SetWindowExtEx(hDC, 10, 10, NULL);
			SetViewportExtEx(hDC, 20, 10, NULL);
			TextOut(hDC, 0, 0, str, _tcsclen(str));
			break;
		case4:
			str = _T("ӳ�䷽ʽMM_ANISOTROPIC:��������Ϊ10*10��ӳ��Ϊ�ӿڳߴ�Ϊ20*5��ͼ����Ŵ�1����������С1��");
			SetMapMode(hDC, MM_ANISOTROPIC);
			SetWindowExtEx(hDC, 10, 10, NULL);
			SetViewportExtEx(hDC, 20, 5, NULL);
			TextOut(hDC, 0, 0, str, _tcsclen(str));
			break;
		case5:
			str = _T("ӳ�䷽ʽMM_ISOTROPIC:��������Ϊ10*10��ӳ��Ϊ�ӿڳߴ�Ϊ20*5��ͼ��Ϊ�˱���ԭ�ݺ�ȣ�ϵͳ���Զ�����ӳ�����");
			SetMapMode(hDC, MM_ISOTROPIC);
			SetWindowExtEx(hDC, 10, 10, NULL);
			SetViewportExtEx(hDC, 20, 5, NULL);
			TextOut(hDC, 0, 0, str, _tcsclen(str));
			break;
		}

		hBrush = (HBRUSH)GetStockObject(DC_BRUSH);
		SelectObject(hDC, hBrush);
		SetDCBrushColor(hDC, RGB(255, 0, 0));
		Rectangle(hDC, 50, 120, 100, 200);

		hPen = CreatePen(PS_SOLID, 1, RGB(0, 255, 0));
		SelectObject(hDC, hPen);
		hBrush = (HBRUSH)GetStockObject(DC_BRUSH);
		SelectObject(hDC, hBrush);
		SetDCBrushColor(hDC, RGB(0, 0, 255));
		Ellipse(hDC, 150, 50, 200, 150);

		hPen = CreatePen(PS_SOLID, 1, RGB(0, 255, 0));
		SelectObject(hDC, hPen);
		hBrush = (HBRUSH)GetStockObject(DC_BRUSH);
		SelectObject(hDC, hBrush);
		SetDCBrushColor(hDC, RGB(255, 0, 0));
		Pie(hDC, 250, 50, 300, 100, 250, 50, 300, 50);

		EndPaint(hWnd, &PtStr);
		break;

	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
		break;
	}
	return 0;
}

WNDCLASSEX wcex;
HWND hWnd;

BOOLEAN InitWindowClass(HINSTANCE hInstance, int nCmdShow)
{
	TCHAR szWindowClass[] = "����ʾ��";
	TCHAR szTitle[] = "2021529620004_LOWRENHONG_Win32Application_3_1";
	wcex.cbSize = sizeof(WNDCLASSEX);
	wcex.style = 0;
	wcex.lpfnWndProc = WndProc;
	wcex.cbClsExtra = 0;
	wcex.hInstance = hInstance;
	wcex.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_APPLICATION));
	wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wcex.lpszMenuName = NULL;
	wcex.lpszClassName = szWindowClass;
	wcex.hIconSm = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_APPLICATION));

	if (!RegisterClassEx(&wcex))
	{
		return FALSE;
	}

	hWnd = CreateWindow(
		szWindowClass,
		szTitle,
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		NULL,
		NULL,
		hInstance,
		NULL
	);
	if (!hWnd)
	{
		return FALSE;
	}
	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);
	return TRUE;
}