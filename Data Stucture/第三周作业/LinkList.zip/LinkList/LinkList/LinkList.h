//
//  LinkList.h
//  LinkList
//
//  Created by RENHONGLOW on 05/10/2024.
//

#include "global.h"

//结构体
typedef struct LNode{
    //数据域
    int data;
    //指针域
    struct LNode *next;
//补全定义
}SLList,*LinkList;

SLList *InitLink();
int ClearSList(SLList *L);
int getLen(SLList *L);
int SLGetElem(SLList *head,int i, ElemType *Item);
SLList* LocateElem(SLList *L,int *i,ElemType Item);
int SLInsert(SLList *L,int i,ElemType Item);
int SLDelete(SLList *L,int i);
void PrintList(SLList * head);
int creatLinkBefore(SLList *p,int n);
int creatLinkAfter(SLList *p,int n);
void LinklistTest();
void SLMerge(SLList * la, SLList *lb);
void SLMergeTest();
int    CreateLinklistAfter(SLList *L);
