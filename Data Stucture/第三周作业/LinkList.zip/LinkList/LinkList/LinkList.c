//
//  LinkList.c
//  LinkList
//
//  Created by RENHONGLOW on 05/10/2024.
//

#include "Linklist.h"

//初始化空链表
SLList *InitLink(SLList *p)
{
    p = (SLList *)malloc(sizeof(SLList));
    //p=L->head; //补全代码  /*创建头结点*/
    if(p==NULL)
    {
        printf("初始化链表内存申请失败！");
        return NULL;
    }
    p->data=0;//补全代码
    p->next=NULL; //补全代码
    return p;
}

//清空链表
int ClearSList(SLList *L)/*使线性表L变成空表*/
{
    SLList *temp;
    while(L->next != NULL)
    {
        temp=L->next;   /*使工作指针指向第1个结点*/
        L->next=L->next->next;
        free(temp);
    }
   return TRUE;
}

//获取链表长度
int getLen(SLList *L)
{
    int len=0;
    SLList *temp;
    temp=L;
    while(temp!=NULL){ //补全代码
        len++;//补全代码
        temp->next;//补全代码
    }
    return len;
}

//获取链表元素
int SLGetElem(SLList *head,int i, ElemType *Item){
    SLList *p;
    int j;
    if(i < 1)
    {
        printf("输入i不合法！\n");
        return FALSE; /*参数i不合适*/
    }
    p = head->next;//补全代码
    j = 1;
    while(p!=NULL&&j<i){ //补全代码   /*从第1个结点开始查找第i个结点*/
        p = p->next;//补全代码
        j++;
    }
    if(p == NULL)
    {
        printf("输入i值超出表长");
        return FALSE; /* i的值超过表长，返回FALSE */
    }
    *Item = p->data;//补全代码
    return TRUE; /*读取成功，返回TRUE */
}

//定位链表元素
SLList* LocateElem(SLList *L,int *i,ElemType Item)
{
    SLList *temp;
    int pos;
    pos=1; /*记值为Item 的结点在表中的位置,该变量可以不要*/
    temp=L->next;   //补全代码   /*使temp指向第一个结点*/
    while(temp!=NULL && temp->data!=Item){//补全代码
        pos++;
        temp=temp->next; //补全代码
    }
    //如果没找到元素就设置为0返回NULL
    if(!temp){
        *i=0;
    }
    //如果找到则返回对应的位置
    else
    {
        *i=pos;
    };//补全代码
    return temp;
}

//插入链表元素
int SLInsert(SLList *L,int i,ElemType Item){
    int j=0;
    SLList *node,*temp;
    if(i < 1)
        {
            printf("输入插入位置错误！\n");
            return FALSE;  /*参数i不正确*/
    }
    temp = L;//补全代码
    while(temp!=NULL&&j<i-1){  //补全代码   /*从头节点开始查找第i-1个节点*/
        temp=temp->next;    //补全代码
        j++;//补全代码
    }
    if(temp == NULL)
        {
            printf("插入位置错误！\n");
            return FALSE; /*已经查找到了表尾, 插入位置错误*/
    }
    node=(SLList*)malloc(sizeof(SLList));
    if(node==NULL)
    {
        printf("插入结点内存申请失败！\n");
        return FALSE; /* 分配内存出错*/
    }
    node->data=Item;  //补全代码，插入结点，data+1
    node->next=temp->next;  //补全代码
    temp->next=node;  //补全代码
    return TRUE;
}

//删除链表元素
int SLDelete(SLList *L,int i){
    SLList *temp,*q;
    int j=0;
    if( i < 1 )
    {
        printf("输入位置错误！\n");
        return FALSE; /*参数i不正确*/
    }
    temp=L; /*工作指针指向头结点*/
    while(temp!=NULL&&j<i-1){ //补全代码
        temp=temp->next; //补全代码
        j++;//补全代码
    }/*找第i-1个结点*/
    if(temp->next==NULL)  /*第i个结点不存在*/
    {
        printf("输入位置错误！\n");
        return FALSE;
    }
    q=temp->next; //补全代码/*q指向第i个结点*/
    temp->next=q->next;//补全代码
    free(q); //补全代码/*释放第i个节点的空间*/
    L->data--;
    return TRUE;
}

//打印链表
void PrintList(SLList * head){
    SLList * p;
    p = head->next;
    if(p==NULL)
        printf("Empty list.\n");
    while(p != NULL){
        printf("%4d", p->data);
        p = p->next;
    }
    printf("\n");
}

//头插法
int creatLinkBefore(SLList *p,int n)
{
    SLList *s;
    int i;
    if(n<1)
    {
        printf("头插法生成链表元素个数小于0!\n");
        return FALSE;
    }
    if(!p)
    {
        p = (SLList*) malloc(sizeof(SLList)); /*创建头结点*/
        if(p==NULL)
        {
            printf("头插法初始化链表内存申请失败！");
            return FALSE;
        }
        p->next=NULL; //先建立一个带头结点的单链表
    }
    p->data=n;
    for(i=1;i<=n;i++)
    {
        s = (SLList*) malloc(sizeof(SLList)); /*创建新结点*/
        if(s == NULL)
        {
            printf("内存申请失败！\n");
            return FALSE;
        }
        printf("请输入第%d个元素的值: ", i);
        scanf("%d", &s->data); //输入结点的数据
        
        s->next = p->next; //将新结点的 next 指向当前链表的第一个结点
        p->next = s;       //将新结点插入到头结点后面
        //补全代码不止一行    //插入到表头
     }
    return TRUE;
}

//尾插法
int creatLinkAfter(SLList *p,int n){
    SLList   *head,*s;
    int i;
    if(n<1)
    {
            printf("尾插法生成链表元素个数小于0!\n");
            return FALSE;
    }
    if(!p)
    {
        p = (SLList*) malloc(sizeof(SLList)); /*创建头结点*/
        if(p==NULL)
        {
            printf("尾插法初始化链表内存申请失败！");
            return FALSE;
        }
        p->next=NULL; //先建立一个带头结点的单链表
    }
    head=p;
    p->data=n;
    for(i=1;i<=n;i++){
        s = (SLList*) malloc(sizeof(SLList)); /*创建新结点*/
        if(s == NULL)
        {
            printf("内存申请失败！\n");
            return FALSE;
        }
        printf("请输入第%d个元素的值: ", i);
        scanf("%d", &s->data); // 输入结点的数据
        
        s->next = NULL;  // 新结点的 `next` 指向 NULL
        p->next = s;     // 当前结点的 `next` 指向新结点
        p = s;           // 更新 `p`，使其指向新插入的结点
        //补全代码不止一行
    }
    p->next = NULL; /*未结点的指针域为空*/
    p=head;
    return TRUE;
}

//测试链表
void LinklistTest()
{
    SLList *L,*Item;
    int choice;
    int InputNum;
    int position;
    int i;
    int e;
    int result;
    
    choice = -1;
    while (choice != 0)
    {
        printf("链表操作示例(请先初始化后再进行其他操作)：\n");
        printf( "1. 初始化\n");
        printf( "2. 头插法建立链表\n");
        printf( "3. 尾插法建立链表\n");
        printf( "4. 取值\n");
        printf( "5. 查找\n");
        printf( "6. 插入\n");
        printf( "7. 删除\n");
        printf( "8. 输出\n");
        printf( "0. 退出\n");
        printf("\n请选择:");
        scanf("%d", &choice);
        switch (choice)
        {
        case 1://链表初始化
            L=InitLink(L);
            if(!L)
                printf("初始化链表失败！\n\n");
            else
                printf("初始化链表成功！\n\n");
            break;
        case 2: //头插法建立链表
            if(L)
                ClearSList(L);//先清空链表数据
            printf("请输入待插入元素个数：");
            scanf("%d",&InputNum);
            printf("\n请输入元素内容：");
            if(creatLinkBefore(L,InputNum))
                printf("头插法生成链表成功！\n");
            printf("头插法后链表内容：\n");
            PrintList(L);
            break;
        case 3://尾插法建立链表
            if(L)
                ClearSList(L);//先清空链表数据
            printf("请输入待插入元素个数：");
            scanf("%d",&InputNum);
            printf("\n请输入元素内容：");
            if(creatLinkAfter(L,InputNum))
                printf("尾插法生成链表成功！\n");
            printf("尾插法后链表内容：\n");
            PrintList(L);
            break;
        case 4://取值
            printf("请输入一个位置用来取值：\n");
            scanf("%d",&i);
            result = SLGetElem(L, i, &e);
            if (result != 0) {
                printf("查找成功\n");
                printf("第%d个元素是：%d\n\n",i,e);
            } else
                printf("查找失败！位置超出范围\n\n");
            break;
        case 5: //按值查找
            printf("请输入所要查找的数值:");
            scanf("%d",&e);
            Item = LocateElem(L,&position, e);
            if (!Item)
            printf( "查找失败！没有这个数值\n\n");
            else{
                printf("查找成功\n");
                printf("该节点是第%d个结点\n\n",position);
            }
                
            break;
        case 6: //链表的插入
            printf("请输入插入的位置:");
            scanf("%d",&i);
            printf("\n请输入插入数值:");
            scanf("%d",&e);
                    
            if (SLInsert(L, i, e))
            {
                printf("\n插入成功.\n\n");
                printf("插入后链表数据个数为：%d\n",L->data);
                printf("插入后链表内容为：");
                PrintList(L);
                printf("\n");
            }
            else
                printf("\n插入失败.\n\n");
            break;
         case 7: //顺序表的删除
            printf( "\n请输入所要删除的数据位置:");
            scanf("%d",&i);
            if (SLDelete(L, i))
            {
                printf("\n删除成功.\n");
                printf("删除后链表数据个数为：%d\n",L->data);
                printf("删除后链表内容为：");
                PrintList(L);
                printf("\n");
            }
            else
                printf("\n删除失败.\n");
            break;
        case 8: //链表的输出
            PrintList(L);
            break;
        }
    }
    
    return ;
 }


