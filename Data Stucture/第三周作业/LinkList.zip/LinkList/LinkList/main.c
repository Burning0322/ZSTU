//
//  main.c
//  LinkList
//
//  Created by RENHONGLOW on 05/10/2024.
//

#include <stdio.h>
#include "LinkList.h"

int main(int argc, const char * argv[]) {
    LinklistTest();
    return 0;
}
