//
//  main.c
//  Exercise3
//
//  Created by RENHONGLOW on 07/10/2024.
//

#include <stdio.h>
#include <stdlib.h>

#define ElemType int
#define INITSIZE 100

typedef struct {
    ElemType *data;
    int length;
    int listsize;
} SqList;

int InitList(SqList *L) {
    L->data = (ElemType*)malloc(sizeof(ElemType)*INITSIZE);
    if(!L->data) {
        printf("动态内存分配失败\n");
        return 0;
    }
    L->length = 0;
    L->listsize = INITSIZE;
    return 1;
}

void Merge(SqList *L1, SqList *L2, SqList *L) {
    int i = 0, j = 0, k = 0;
    InitList(L);
    
    // 合并两个有序表，并删除重复元素
    while (i < L1->length && j < L2->length) {
        if (L1->data[i] < L2->data[j]) {
            if (k == 0 || L->data[k-1] != L1->data[i]) { // 检查重复
                L->data[k++] = L1->data[i];
            }
            i++;
        } else if (L1->data[i] > L2->data[j]) {
            if (k == 0 || L->data[k-1] != L2->data[j]) { // 检查重复
                L->data[k++] = L2->data[j];
            }
            j++;
        } else { // L1->data[i] == L2->data[j]
            if (k == 0 || L->data[k-1] != L1->data[i]) { // 检查重复
                L->data[k++] = L1->data[i];
            }
            i++;
            j++;
        }
    }

    // 处理 L1 剩余的元素
    while (i < L1->length) {
        if (k == 0 || L->data[k-1] != L1->data[i]) {
            L->data[k++] = L1->data[i];
        }
        i++;
    }

    // 处理 L2 剩余的元素
    while (j < L2->length) {
        if (k == 0 || L->data[k-1] != L2->data[j]) {
            L->data[k++] = L2->data[j];
        }
        j++;
    }

    // 更新顺序表 L 的长度
    L->length = k;
}

void Output(SqList *L) {
    if (L->length == 0) {
        printf("顺序表为空\n");
        return;
    }
    for (int i = 0; i < L->length; i++) {
        printf("%d ", L->data[i]);
    }
    printf("\n");
}

int main(int argc, const char * argv[]) {
    SqList L1, L2, L;
    InitList(&L1);
    InitList(&L2);
    
    L1.data[0] = 1;
    L1.data[1] = 3;
    L1.data[2] = 5;
    L1.data[3] = 7;
    L1.length = 4;
    
    L2.data[0] = 2;
    L2.data[1] = 3;
    L2.data[2] = 6;
    L2.data[3] = 8;
    L2.length = 4;
    
    Merge(&L1, &L2, &L);
    printf("合并后的顺序表: ");
    Output(&L);
    return 0;
}
