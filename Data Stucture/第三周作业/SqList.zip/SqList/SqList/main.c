//
//  main.c
//  SqList
//
//  Created by RENHONGLOW on 29/09/2024.
//

#include <stdio.h>
#include "SqList.h"


int main(int argc, const char * argv[]) {
    SqlistTest();
    return 0;
}
