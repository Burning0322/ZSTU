//
//  SqList.h
//  SqList
//
//  Created by RENHONGLOW on 29/09/2024.
//
#include "global.h"

typedef struct
{
    //顺序表元素
    ElemType *data;
    //顺序表长度
    int length;
    //顺序表容量
    int listsize;
}SqList;

void SqlistTest();
//初始化顺序表
int InitList(SqList *L);
//获取顺序表的长度
int GetLen(SqList *L);
//获取顺序表的元素
int GetELem(SqList *L,int i,ElemType *e);
//查询元素
int Locate(SqList *L,ElemType x);
//清空顺序表
void ClearList(SqList *L);
//重新分配空间
void againMalloc(SqList *L);
//插入顺序表
int Insert(SqList *L,int i, ElemType item);
//删除元素
int DeleteElem(SqList *L,int i);
//输出元素
void OutputList(SqList *L);
//创建顺序表
void CreateSqList(SqList *L);


