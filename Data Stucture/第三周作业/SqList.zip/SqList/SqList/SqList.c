//
//  SqList.c
//  SqList
//
//  Created by RENHONGLOW on 29/09/2024.
//
#include "SqList.h"
#include <stdlib.h>
#include <stdio.h>

//初始化顺序表
int InitList(SqList *L)
{
    //存储空间分配内存
    L->data=(ElemType*)malloc(sizeof(ElemType)*INITSIZE);
    //判断分配成功
    if(!L->data)
    {
        printf("动态内存分配失败\n");
        return FALSE;
    }
    //初始化长度
    L->length=0;
    //初始化容量
    L->listsize=INITSIZE;
    return TRUE;
}

//获取顺序表的长度
int GetLen(SqList *L)
{
    //返回顺序表长度
    return L->length;
}

//获取顺序表的元素
int GetELem(SqList *L,int i,ElemType *e)
{
    //判断i的合法性
    if(i<1||i>L->length)
    {
        return FALSE;
    }
    else
    {
        *e=L->data[i-1];
        return TRUE;
    }
}

//查询元素
int Locate(SqList *L,ElemType x)
{
    int i=0;
    while((i<L->length)&&(L->data[i]!=x))
    {
        i++;
    }
    if(i<L->length)
    {
        return i+1;
    }
    else
    {
        printf("没找到%d",x);
        return ERROR;
    }
}

//清空顺序表
void ClearList(SqList *L)
{
    free(L->data);
    L->data=(ElemType*)malloc(sizeof(ElemType)*INITSIZE);
    L->length=0;
    L->listsize=INITSIZE;
}

//重新分配空间
void againMalloc(SqList *L)
{
    ElemType *p=(ElemType*)realloc((L->data),2*L->listsize*(sizeof(ElemType)));
    if(!p)
    {
        printf("空间分配失败");
        return;
    }
    L->data=p;
    L->listsize=2*L->listsize;
}

//插入顺序表
int Insert(SqList *L,int i, ElemType item)
{
    if(i<1||i>L->length+1)
    {
        printf("超出范围了");
        return FALSE;
    }
    if(L->length==L->listsize)
    {
        againMalloc(L);
    }
    for(int j=L->length;j>i-1;j--)
    {
        //元素向后移
        L->data[j]=L->data[j-1];
    }
    L->data[i-1]=item;
    L->length++;
    return TRUE;
}

//删除元素
int DeleteElem(SqList *L,int i)
{
    if(i<1||i>L->length-1)
    {
        printf("元素超出范围了");
        return FALSE;
    }
    for(int j=i;j>L->length;j++)
    {
        L->data[j-1]=L->data[j];
    }
    L->length--;
    return TRUE;
}

//输出元素
void OutputList(SqList *L)
{
    if(L->length==0)
    {
        printf("顺序表为空");
    }
    for(int i=0;i<L->length;i++)
    {
        printf("%d",L->data[i]);
    }
    printf("\n\n");
}

//创建顺序表
void CreateSqList(SqList *L)
{
    int n;
    ElemType item;
    InitList(L);
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        printf("输入顺序表的元素:");
        scanf("%d",&item);
        if(!Insert(L,i,item))
        {
            printf("插入元素失败\n");
            return;
        }
        Insert(L,i,item);
    }
}

//测试链表
void SqlistTest()
{
    SqList L;
    int choice;
    int InputNum;
    int i;
    int e;
    int result;
    
    choice = -1;
    while (choice != 0)
    {
        printf("线性表示例：\n");
        printf( "1. 建立\n");
        printf( "2. 输入\n");
        printf( "3. 取值\n");
        printf( "4. 查找\n");
        printf( "5. 插入\n");
        printf( "6. 删除\n");
        printf( "7. 输出\n");
        printf( "0. 退出\n\n");
        printf("\n请选择:");
        scanf("%d", &choice);
        switch (choice)
        {
        case 1://创建顺序表
            if (InitList(&L))
                printf("成功建立顺序表\n\n");
            else
                printf( "顺序表建立失败\n\n");
            break;
        case 2: //顺序表信息输入
            ClearList(&L);
            printf("请输入顺序表元素个数：");
            scanf("%d",&InputNum);
            for (i=0;i<InputNum;i++)
            {
                printf("请输入第%d元素：",i+1);
                scanf("%d",&L.data[i]);
            }
            L.length=InputNum;
            printf("输入数据成功！\n\n");
            break;
        case 3:
            //顺序表的取值
            printf("请输入一个位置用来取值：\n");
            //输入要查找的值
            scanf("%d",&i);
            //判断是否越界
            if(i<1||i>L.length)
            {
                printf("未查找到此元素\n\n");
                break;
            }
            else{
                printf("%d个位置元素是%d\n\n",i,L.data[i-1]);
            }
            break;
        case 4:
            //顺序表的查找
            printf("请输入所要查找的数值:");
            scanf("%d",&e);
            result=Locate(&L,e);
            if(result!=ERROR)
            {
                printf("查询到%d在位置%d\n\n",e,result);
                break;
            }
            else
            {
                printf("未查询到%d\n\n",e);
                break;
            }
            break;
        case 5: //顺序表的插入
            printf("请输入插入的位置:");
            scanf("%d",&i);
            printf("\n请输入插入数值:");
            scanf("%d",&e);
            if(Insert(&L,i,e))
            {
                printf("%d数值插入成功在%d位置上\n\n",e,i);
                break;
            }
            else
            {
                printf("\n插入元素失败\n\n");
                break;
            }
            break;
         case 6: //顺序表的删除
            printf( "请输入所要删除的数据位置:");
            scanf("%d",&i);
            if(DeleteElem(&L,i))
            {
                printf("删除成功\n\n");
            }
            else
            {
                printf("删除失败\n\n");
            }
            break;
        case 7: //顺序表的输出
            OutputList(&L);
            break;
        }
    }
    return ;

}
