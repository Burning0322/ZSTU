//
//  global.h
//  SqList
//
//  Created by RENHONGLOW on 29/09/2024.
//
#include<string.h>
#include<ctype.h>
//#include<malloc.h> /* malloc()等 */
#include <sys/malloc.h>
#include<limits.h> /* INT_MAX等 */
#include<stdio.h> /* EOF(=^Z或F6),NULL */
#include<stdlib.h> /* atoi() */
//#include<io.h> /* eof() */
#include<sys/uio.h>
#include<math.h> /* floor(),ceil(),abs() */
//#include<process.h> /* exit() */
#define OK 1
#define ERROR 0
//#define OVERFLOW -2
#define INITSIZE 100            //顺序表可能达到的最大长度
#define TRUE 1
#define FALSE 0
typedef int Status; //Status 是函数返回值类型，其值是函数结果状态代码。
typedef int ElemType; //ElemType 为可定义的数据类型，此设为int类型
