public interface UserDatabase {
    Boolean login (String userName, String password);
    Boolean register (String userName, String password);
    Boolean logout ();
}
