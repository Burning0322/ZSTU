public interface Data {
    void init();
    Boolean loadData(String dataPath);
    Boolean saveData(String savePath);
}
