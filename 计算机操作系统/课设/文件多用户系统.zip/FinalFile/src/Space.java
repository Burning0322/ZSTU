public class Space {
    public static int ceilDivide(int dividend,int divisor) {
        if (dividend % divisor == 0) {
            // 整除
            return dividend / divisor;
        } else {
            // 不整除，向上取整
            return (dividend + divisor) / divisor;
        }
    }
    public static boolean isAllSpace(String str) {
        return (str == null || "".equals(str.trim()));
    }
    public static String[] inputResolve(String input) {
        if (Space.isAllSpace(input)) {
            return new String[]{""};
        }

        return input.trim().split("\\s+"); //匹配多个空格
    }

    public static String getFormatLogString(String content, int colour, int type) {
        boolean hasType = type != 1 && type != 3 && type != 4;
        if (hasType) {
            return String.format("\033[%dm%s\033[0m", colour, content);
        } else {
            return String.format("\033[%d;%dm%s\033[0m", colour, type, content);
        }
    }
    public static String getSuffix(String fileName) {
        if (fileName == null || "".equals(fileName)) {
            return "";
        }
        int index = fileName.lastIndexOf(".");
        if (index == fileName.length()) {
            return "";
        }
        return fileName.substring(index + 1, fileName.length());
    }
}
