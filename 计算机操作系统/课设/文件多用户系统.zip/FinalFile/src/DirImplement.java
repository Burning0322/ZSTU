import java.util.*;

public class DirImplement implements Dir {
    private static final Dir DIR = new DirImplement();
    private static final FileService fileService = new FileServiceImplement();
    private static final Scanner scanner=new Scanner(System.in);
    private static final DiskDatabase DISK_DATABASE = new DiskDatabaseImplement();

    public static void main(String[] args) {
        StringBuilder sb = new StringBuilder(); // 创建一个空的StringBuilder对象

        sb.insert(0, '1'); // 在索引0的位置插入字符'1'
        sb.insert(0, '2'); // 在索引0的位置插入字符'2'，将字符'1'向后移动
        sb.insert(0, '3'); // 在索引0的位置插入字符'3'，将字符'2'和'1'向后移动

        System.out.println(sb.toString()); // 将StringBuilder转换为字符串并打印

    }
    @Override
    public void dir() {
        // 获取存储实例，并获取当前目录的子项列表
        Storage storage = Storage.getInstance();
        List<FCB> children = storage.getCurDir().getChildren();
        View view = new View();
        System.out.println("Permission\tOwner\tSize\t\tLastModifyDate\t\t\t\t\t\tName");
        for (int i = 0; i < children.size(); i++) {
            FCB fcb = children.get(i);
            if (fcb.getType().equals('N')) {
                String suffix = Space.getSuffix(fcb.getFileName()).toLowerCase();
                switch (suffix) {
                    case "exe":
                        // Executable files (e.g., .exe)
                        view.showFcb(fcb, 36); // Green
                        break;
                    case "tar":
                    case "zip":
                    case "rar":
                        // Compressed files (e.g., .tar, .zip, .rar)
                        view.showFcb(fcb, 31); // Red
                        break;
                    case "jpg":
                    case "jpeg":
                    case "png":
                        // Image files (e.g., .jpg, .jpeg, .png)
                        view.showFcb(fcb, 35); // Purple
                        break;
                    case "mp3":
                    case "wav":
                    case "ogg":
                        // Audio files (e.g., .mp3, .wav, .ogg)
                        view.showFcb(fcb, 33); // Yellow
                        break;
                    case "pdf":
                    case "doc":
                    case "docx":
                    case "ppt":
                    case "pptx":
                    case "xls":
                    case "xlsx":
                        // Document files (e.g., .pdf, .doc, .ppt)
                        view.showFcb(fcb, 32); // Green
                        break;
                    case "java":
                    case "py":
                    case "c":
                    case "cpp":
                        // Program source code files (e.g., .java, .py, .c)
                        view.showFcb(fcb, 94); // Light Blue
                        break;
                    default:
                        // Other regular files
                        view.showFcb(fcb, -1); // Default color
                        break;
                }
            } else {
                // Directories
                view.showFcb(fcb, 34); // Blue
            }
        }
    }

    @Override
    public Boolean mkdir(String dirName,String permission) {
        //getInstance是获取存储实列，getCurDir是获取当前目录的FCB
        FCB curDir = Storage.getInstance().getCurDir();
        //获取当前用户
        User user = Storage.getInstance().getCurUser();
        //curDir.getChildren() 获取当前目录的子项列表
        List<FCB> children = curDir.getChildren();
        //判空
        if(Objects.isNull(dirName)){
            System.out.println("[error]: Directory can't be null");
            return false;
        }
        //判断重复
        dirName = dirName.trim(); //去除首尾空格
        for (FCB child : children) {
            if(child.getFileName().equals(dirName)){
                System.out.println("[error]: Directory repeat,rename Directory");
                return false;
            }
        }
        //创建索引节点 创建FCB 文件大小为0 空文件
        FileIndex fileIndex = new FileIndex(permission, 0, -1, 0, user.getUserName(), new Date());
        FCB fcb = new FCB(dirName, 'D', fileIndex, curDir, new LinkedList<>());
        //将文件控制块放入磁盘的fcb集合
        Disk.getINSTANCE().getFcbList().add(fcb);
        //修改父目录的文件项 加入父目录儿子集合
        curDir.getIndexNode().addFcbNum();
        curDir.getChildren().add(fcb);
        System.out.println("[success]: Created Directory！");
        return true;
    }

    @Override
    public Boolean rmdir(String filePath) {
        //判断是否存在
        FCB fcb = DIR.pathResolve(filePath);
        if(Objects.isNull(fcb)){
            System.out.println("[error]: Directory doesn't exits");
            return false;
        }
        //判断权限 需要对文件夹具有rwx权限 对文件具有rw权限
        int per_father = fileService.checkPermission(fcb.getFather());
        int permission = fileService.checkPermission(fcb);
        if(!(per_father == 7 && (permission == 7 || permission == 6))){
            System.out.println("[error]: Invalid permission");
            return false;
        }
        //重复确认
        String choice = null;
        while (true){
            System.out.println("Confirm delete directory?（Y/N）");
            choice = scanner.nextLine();
            if(choice.equals("Y")) break;
            if(choice.equals("N")) {
                System.out.println("[success]: Cancel delete！");
                return false;
            }
        }
        //空文件判断
        if(fcb.getIndexNode().getSize() != 0 || fcb.getIndexNode().getFcbNum() != 0){
            if(fcb.getType().equals('D')){
                //type D 目录
                //diskService.freeDir(fcb);
                System.out.println("[error]: Directory isn't empty cannot delete,confirm delete?[Y/N]");
                String choice2=null;
                choice2=scanner.nextLine();
                if(choice.equals("Y"))
                {
                    //从FCB集合中去除 修改父目录文件项 修改父目录儿子结点
                    Disk.getINSTANCE().getFcbList().remove(fcb);
                    fcb.getFather().getIndexNode().subFcbNum();
                    fcb.getFather().getChildren().remove(fcb);
                    //递归修改父目录文件大小
                    DIR.updateSize(fcb,false,-1);
                    System.out.println("[success]: Deleted");
                    return true;
                }
                if(choice.equals("N")) {
                    System.out.println("[success]: Cancel delete！");
                }
                return false;
            }else {
                //清空磁盘
                DISK_DATABASE.freeFile(fcb);
            }
        }
        return true;
    }

    @Override
    public Boolean cd(String path) {
        //判断是否直接切换到根目录
        if("/".equals(path.trim())){
            Storage.getInstance().setCurDir(Storage.getInstance().getRootDir());
            return true;
        }
        //判断是不是..  ../
        if("..".equals(path.trim()) || "../".equals(path.trim()) || ".".equals(path.trim())){
            FCB curDir = Storage.getInstance().getCurDir();
            //判断是不是已经在根目录
            if(curDir != Storage.getInstance().getRootDir()){
                //改变当前目录为父目录
                Storage.getInstance().setCurDir(curDir.getFather());
            }
            return true;

        }
        //解析路径
        FCB fcb = DIR.pathResolve(path);
        //null 不存在
        if(Objects.isNull(fcb)){
            System.out.println("[error]: Directory doesn't exits");
            return false;
        }else if(fcb.getType().equals('N')){
            //type N 不是目录文件
            System.out.println("[error]: Cannot open file");
            return false;
        }else {
            //type D 切换到对应目录
            //判断权限
            int permission = fileService.checkPermission(fcb);
            if(permission == 0){
                System.out.println("[error]: Doesn't have permission");
                return false;
            }
            Storage.getInstance().setCurDir(fcb);
        }
        return null;
    }
    @Override
    public FCB pathResolve(String path) {
        path = path.trim();
        FCB curDir = Storage.getInstance().getCurDir();
        FCB rootDir = Storage.getInstance().getRootDir();
        //判断是不是/开头 不是就是当前目录找
        if(!path.startsWith("/")){
            for (FCB child : curDir.getChildren()) {
                if(child.getFileName().equals(path)){
                    return child;
                }
            }
        }else {
            //以/开头 从根目录逐层往下找
            path = path.substring(1);
            String[] splitDir = path.split("/");
            FCB temp = rootDir;
            for (int i = 0; i < splitDir.length - 1; i++) {
                //找到目标文件所在目录
                for (FCB child : temp.getChildren()) {
                    if(child.getFileName().equals(splitDir[i])){
                        temp = child;
                        continue;
                    }
                }
            }
            //在该目录下找
            for (FCB child : temp.getChildren()) {
                if(child.getFileName().equals(splitDir[splitDir.length - 1])){
                    return child;
                }
            }
        }
        return null;
    }

    @Override
    public void updateSize(FCB fcb, Boolean isAdd, int new_add) {
        FCB temp = fcb.getFather();
        while (temp != Storage.getInstance().getRootDir()){
            //递归修改父目录的大小
            int size = temp.getIndexNode().getSize();
            if(isAdd){
                if(new_add == -1){
                    //增加目录大小
                    temp.getIndexNode().setSize(size + fcb.getIndexNode().getSize());
                }else {
                    temp.getIndexNode().setSize(size + new_add);
                }
            }else {
                temp.getIndexNode().setSize(size - fcb.getIndexNode().getSize());
            }
            temp = temp.getFather();
        }
    }

    @Override
    public void ls() {
        Storage storage = Storage.getInstance();
        List<FCB> children = storage.getCurDir().getChildren();
        for (int i = 0; i < children.size(); i++) {
            FCB fcb = children.get(i);
            if(fcb.getType().equals('N')){
                if(Space.getSuffix(fcb.getFileName()).equals("exe")){
                    System.out.print(Space.getFormatLogString(fcb.getFileName(),36,0) + " ");
                }else if(Space.getSuffix(fcb.getFileName()).equals("tar") || Space.getSuffix(fcb.getFileName()).equals("zip") || Space.getSuffix(fcb.getFileName()).equals("zip") || Space.getSuffix(fcb.getFileName()).equals("rar")){
                    System.out.print(Space.getFormatLogString(fcb.getFileName(),31,0) + " ");
                }else {
                    System.out.print(fcb.getFileName() + " ");
                }
            }else {
                System.out.print(Space.getFormatLogString(fcb.getFileName(),34,0) + " ");
            }
        }
    }

    @Override
    public String pwd(FCB fcb) {
        Storage storage = Storage.getInstance();
        StringBuilder sb = new StringBuilder();
        FCB temp = fcb;
        while (temp != storage.getRootDir()){
            //还没打印到根目录
            sb.insert(0,temp.getFileName());
            sb.insert(0,'/');
            temp = temp.getFather();
        }
        return sb.toString();
    }

    @Override
    public void showPath() {
        Storage storage = Storage.getInstance();
        StringBuilder sb = new StringBuilder();
        sb.append("\n[");
        sb.append(storage.getCurUser().getUserName() + "@");
        sb.append(" ");
        sb.append(storage.getCurDir().equals(storage.getRootDir()) ? "/" : storage.getCurDir().getFileName());
        sb.append("]");
        System.out.print(sb);
    }
    @Override public void bitmap() {
        FAT[] fats = Storage.getInstance().getFat();
        for (int i = 0; i < fats.length; i++) {
            System.out.print(fats[i].getBitmap() + " ");
            if((i+1) % Set.WORD_SIZE == 0){
                System.out.println();
            }
        }
    }

    @Override
    public void displayRemainingSpace() {
        Storage storage=Storage.getInstance();
        int totalBlocks = storage.getFat().length;
        int usedBlocks = totalBlocks - storage.getEmpty_blockNum();
        int remainingBlocks = storage.getEmpty_blockNum();

        System.out.println("Total Blocks: " + totalBlocks);
        System.out.println("Used Blocks: " + usedBlocks);
        System.out.println("Remaining Blocks: " + remainingBlocks);
    }

}