import java.io.*;
import java.util.*;

public class DataImplement implements Data {
    @Override
    public void init() {
        Disk newDisk = Disk.getINSTANCE();
        Block[] disk = new Block[Set.BLOCK_COUNT];

        //初始化磁盘
        for (int i = 0; i < Set.BLOCK_COUNT; i++) {
            disk[i] = new Block();
            disk[i].setId(i);
            disk[i].setBlockSize(Set.BLOCK_SIZE);
            disk[i].setContent(null);
        }
        newDisk.setDisk(disk);

        //初始化FCB集合
        List<FCB> fcbList = new ArrayList<>();
        newDisk.setFcbList(fcbList);

        //初始化根目录
        FileIndex fileIndex = new FileIndex("rwx",0,-1,0,null,new Date());
        FCB rootDir = new FCB("rootDir",'D', fileIndex,null,new LinkedList<>());
        fcbList.add(rootDir);

        //初始化FAT表
        FAT[] fats = new FAT[Set.BLOCK_COUNT];
        for (int i = 0; i < Set.BLOCK_COUNT; i++) {
            fats[i] = new FAT();
            fats[i].setId(i);
            fats[i].setBitmap(0);
            fats[i].setNextId(-1);
        }
        newDisk.setFat(fats);

        //初始化内存
        Storage storage = Storage.getInstance();

        //用户集合
        Map<String, User> userMap = new HashMap<>();
        newDisk.setUserMap(userMap);

        //初始化内存
        storage.setUserMap(userMap);
        storage.setCurDir(rootDir);
        storage.setCurUser(null);
        storage.setRootDir(rootDir);
        storage.setFat(fats);
        ArrayList<Open> opens = new ArrayList<>();
        storage.setOpenFileList(opens);
        storage.setEmpty_blockNum(Set.BLOCK_COUNT);
        System.out.println("[success]Init success");
    }

    @Override
    public Boolean loadData(String dataPath) {
        File file = new File(dataPath);
        if (!file.exists()) {
            System.out.println("[error]:Invalid file");
            return false;
        }
        ObjectInputStream ois = null;
        try {
            ois = new ObjectInputStream(new FileInputStream(file));

            //加载磁盘数据
            Disk.setINSTANCE((Disk) ois.readObject());
            Disk instance = Disk.getINSTANCE();

            //将磁盘数据调入内存
            Storage storage = Storage.getInstance();
            storage.setUserMap(instance.getUserMap());
            storage.setCurUser(null);
            storage.setRootDir(instance.getFcbList().get(0));
            storage.setCurDir(instance.getFcbList().get(0));
            FAT[] fats = instance.getFat();
            storage.setFat(fats);
            List<Open> openList = new ArrayList<>();
            storage.setOpenFileList(openList);
            int empty_blockNum = 0;
            for (int i = 0; i < fats.length; i++) {
                if(fats[i].getBitmap() == 0){
                    empty_blockNum++;
                }
            }
            storage.setEmpty_blockNum(empty_blockNum);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("[error]:IO ERROR");
            return false;
        }finally {
            try {
                if (Objects.nonNull(ois)) {
                    ois.close();
                }
            } catch (IOException ignored) {
            }
        }
        System.out.println("[success]Data loaded successful");
        return true;
    }

    @Override
    public Boolean saveData(String savePath) {
        File file = new File(savePath);
        // 检查文件是否存在
        if (!file.exists()) {
            if (!file.getParentFile().exists()) {
                if (new File(file.getParentFile().getPath()).mkdirs()) {
                    try {
                        if (!file.createNewFile()) {
                            System.out.println("[error]:Save error");
                            return false;
                        }
                    } catch (IOException ioException) {
                        System.out.println("[error]:IO ERROR");
                        return false;
                    }
                } else {
                    System.out.println("[error]:Save error");
                    return false;
                }
            }
        }

        ObjectOutputStream oos = null;
        try {
            oos = new ObjectOutputStream(new FileOutputStream(file));
            // 持久化到保存文件中
            oos.writeObject(Disk.getINSTANCE());
            oos.flush();
            System.out.println("[success]Data saved");
            return true;
        } catch (IOException e) {
            System.out.println("[error]:Failed save");
            return false;
        } finally {
            try {
                if (Objects.nonNull(oos)) {
                    oos.close();
                }
            } catch (IOException ignored) {
            }
        }
    }
}