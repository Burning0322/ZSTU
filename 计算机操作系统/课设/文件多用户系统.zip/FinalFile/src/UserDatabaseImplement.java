import java.util.*;

public class UserDatabaseImplement implements UserDatabase {
    Storage instance = Storage.getInstance();
    @Override
    public Boolean login(String userName, String password) {
        //判断当前是否登录
        if(Objects.nonNull(instance.getCurUser())){
            System.out.println("[error]:PLease logout then login");
            return false;
        }
        //用户名或密码错误
        User user = instance.getUserMap().get(userName);
        if(Objects.isNull(user) || Objects.nonNull(user) && !user.getPassword().equals(password)){
            System.out.println("[error]:Username or password is incorrect");
            return false;
        }
        //设置memory量
        //找到用户目录的FCB
        List<FCB> fcbList = Disk.getINSTANCE().getFcbList();
        for (int i = 0; i < fcbList.size(); i++) {
            if(fcbList.get(i).getFileName().equals(userName)){
                //用户目录FCB
                instance.setCurUser(user);
                instance.setCurDir(fcbList.get(i));
            }
        }
        System.out.println("[success]Logged！ Last time login:"+user.getLastLoginTime());
        user.setLastLoginTime(new Date());
        return true;
    }

    @Override
    public Boolean register(String userName, String password) {
        //判断是否登录
        if (Objects.nonNull(instance.getCurUser())) {
            System.out.println("[error]:PLease logout then login");
            return false;
        }
        Map<String, User> userMap = instance.getUserMap();
        //判断是否重复
        if(Objects.nonNull(userMap.get(userName))){
            System.out.println("[error]:Username exits");
            return false;
        }
        //放进用户集合
        userMap.put(userName,new User(userName,password,null));
        //新建一个用户FCB及索引结点 其他用户无权限
        FCB rootDir = instance.getRootDir();
        FileIndex fileIndex = new FileIndex("rwx---",0,-1,0,userName,new Date());
        FCB user_fcb = new FCB(userName,'D', fileIndex, rootDir,new LinkedList<>());
        //放进fcb集合
        Disk.getINSTANCE().getFcbList().add(user_fcb);
        //修改根目录
        rootDir.getChildren().add(user_fcb);
        rootDir.getIndexNode().addFcbNum();
        System.out.println("[success]：Register successfull");
        return true;
    }

    @Override
    public Boolean logout() {
        //判断
        if(Objects.isNull(instance.getCurUser())){
            System.out.println("[error]:PLease logout then login");
            return false;
        }
        //判断是否有文件未关闭
        if(Storage.getInstance().getOpenFileList().size() > 0){
            System.out.println("[error] File haven't close yet please close file first");
            return false;
        }
        instance.setCurUser(null);
        instance.setCurDir(instance.getRootDir());
        instance.getOpenFileList().clear();
        Data data = new DataImplement();
        data.saveData(Set.Path);
        return true;
    }
}
