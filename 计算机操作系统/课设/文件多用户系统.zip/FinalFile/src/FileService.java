public interface FileService {
    Boolean create(String fileName, String permission);
    Boolean open(String filePath);
    void show_open();
    Boolean read(String filePath);
    Boolean write(String filePath);
    Boolean close(String filePath);
    Boolean delete(String filePath);
    int checkPermission(FCB fcb);
    Boolean rename(String filePath,String newName);
}
