public interface Dir {
    void dir();
    Boolean mkdir(String dirName,String permission);
    Boolean rmdir(String filePath);
    Boolean cd(String dirName);
    FCB pathResolve(String path);
    void updateSize(FCB fcb,Boolean isAdd,int new_add);
    void ls();
    String pwd(FCB fcb);
    void showPath();
    void bitmap();
    void displayRemainingSpace();
}
