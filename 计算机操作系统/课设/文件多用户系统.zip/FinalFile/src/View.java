public class View {
    public void help(){
        System.out.println("<mkdir> [dirName] create directory");
        System.out.println("<rmdir> [dirName] delete directory");
        System.out.println("touch [fileName] create file");
        System.out.println("<cd> [fileName] change file");
        System.out.println("<vim> [fileName] open file");
        System.out.println("<close> [fileName] close file");
        System.out.println("<cat> [fileName] read file");
        System.out.println("<write> [fileName] write file");
        System.out.println("rm [fileName] delete file");
        System.out.println("<show> show open file");
        System.out.println("<ls> list show");
        System.out.println("rn [filePath] [newName] file rename");
        System.out.println("<dir/ll> directory/list");
        System.out.println("<storage> Check left Storage block");
    }
    public void showFcb(FCB fcb, int color) {
        // 获取文件的索引节点（FileIndex 对象）
        FileIndex fileIndex = fcb.getIndexNode();

        // 使用格式化字符串输出文件控制块的信息
        /*
        %-6s: 文件权限，表示一个左对齐的字符串，最大宽度为6。
        %-2d: FCB编号，表示一个左对齐的整数，最大宽度为2。
        %-5s: 创建者，表示一个左对齐的字符串，最大宽度为5。
        %-3d: 文件大小，表示一个左对齐的整数，最大宽度为3。
        %28s: 更新时间，表示一个字符串，最大宽度为28。
        %-8s: 文件名，表示一个左对齐的字符串，最大宽度为8。
        */
        System.out.printf("\t%-6s\t  %-5s\t  %-3d\t%28s\t%-8s",
                fileIndex.getPermission(),  // 文件权限
                fileIndex.getCreator(),     // 创建者
                fileIndex.getSize(),        // 文件大小
                fileIndex.getUpdateTime(),  // 更新时间
                // 根据颜色参数判断是否需要对文件名进行格式化处理
                color == -1 ? fcb.getFileName() : Space.getFormatLogString(fcb.getFileName(), color, 0));

        // 输出换行符，使输出格式更清晰
        System.out.println();
    }

}
