import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;

public class FileServiceImplement implements FileService {
    private static final Dir DIR = new DirImplement();
    private static final FileService fileService = new FileServiceImplement();
    private static final DiskDatabase DISK_DATABASE = new DiskDatabaseImplement();
    private static final Scanner scanner = new Scanner(System.in);
    @Override
    public Boolean create(String fileName,String permission) {
        FCB curDir = Storage.getInstance().getCurDir();
        User user = Storage.getInstance().getCurUser();
        List<FCB> children = curDir.getChildren();
        //判空
        if(Objects.isNull(fileName)) {
            System.out.println("[error]: File name can't be empty");
            return false;
        }
        //判断重复
        fileName = fileName.trim(); //去除首尾空格
        for (FCB child : children) {
            if(child.getFileName().equals(fileName)){
                System.out.println("[error]: Filename duplicated rename filename");
                return false;
            }
        }
        //创建索引节点 创建FCB 文件大小为0 空文件
        FileIndex fileIndex = new FileIndex(permission, 0, -1, 0, user.getUserName(), new Date());
        FCB fcb = new FCB(fileName, 'N', fileIndex, curDir, null);
        //将文件控制块放入磁盘的fcb集合
        Disk.getINSTANCE().getFcbList().add(fcb);
        //修改父目录的文件项 加入父目录儿子集合
        curDir.getIndexNode().addFcbNum();
        curDir.getChildren().add(fcb);
        System.out.println("[success]: File created！");
        return true;
    }

    @Override
    public Boolean open(String filePath) {
        //使用pathResolve解析
        FCB fcb = DIR.pathResolve(filePath);
        //null 不存在
        if(Objects.isNull(fcb)){
            System.out.println("[error]: File doesn't exits");
            return false;
        }else if(fcb.getType().equals('D')){
            //type D 不是普通文件
            System.out.println("[error]: Cannot open directory");
            return false;
        }else {
            //type N 普通文件
            //判断权限
            int permission = fileService.checkPermission(fcb);
            if(permission == 0){
                System.out.println("[error]: Permission isn't granted");
                return false;
            }
            //判断是否已经打开
            //判断是否在openFileList中
            String fill_path = DIR.pwd(fcb);
            List<Open> openList = Storage.getInstance().getOpenFileList();
            Open toWriteFile = null;
            for (Open open : openList) {
                if(open.getFilePath().equals(fill_path)){
                    toWriteFile = open;
                }
            }
            if(Objects.nonNull(toWriteFile)){
                System.out.println("[error]: File already opened！");
                return false;
            }
            //加入openFileList中
            Open open = new Open(fcb, fill_path);
            Storage.getInstance().getOpenFileList().add(open);
            System.out.println("[success]: Open！");
            return true;
        }
    }

    @Override
    public void show_open() {
        if(Storage.getInstance().getOpenFileList().size() == 0){
            System.out.println("Cannot open file");
        }
        for (int i = 0; i < Storage.getInstance().getOpenFileList().size(); i++) {
            System.out.print(Storage.getInstance().getOpenFileList().get(i).getFcb().getFileName() + "\t");
        }
    }


    @Override
    public Boolean read(String filePath) {
        //判断是否存在
        FCB fcb = DIR.pathResolve(filePath);
        if(Objects.isNull(fcb)){
            System.out.println("[error]: File doesn't exits");
            return false;
        }else if(fcb.getType().equals('D')){
            //type D 不是普通文件
            System.out.println("[error]: Cannot read directory");
            return false;
        }else {
            //type N 普通文件
            //判断文件权限
            int permission = fileService.checkPermission(fcb);
            if(permission == 0){
                System.out.println("[error]: Permission isn't granted");
                return false;
            }
            //判断是否在openFileList中
            String fill_path = DIR.pwd(fcb);
            List<Open> openList = Storage.getInstance().getOpenFileList();
            Open toWriteFile = null;
            for (Open open : openList) {
                if(open.getFilePath().equals(fill_path)){
                    toWriteFile = open;
                }
            }
            if(Objects.nonNull(toWriteFile)){
                FAT[] fats = Storage.getInstance().getFat();
                Block[] disk = Disk.getINSTANCE().getDisk();
                //从磁盘读取
                if(fcb.getIndexNode().getSize() == 0){
                    System.out.println("<!!!EMPTY FILE!!!>");
                    return false;
                }
                FAT temp = fats[fcb.getIndexNode().getFirst_block()];
                while (temp.getNextId() != -1){
                    //遍历输出
                    System.out.print(disk[temp.getId()].getContent());
                    temp = fats[temp.getNextId()];
                }
                System.out.print(disk[temp.getId()].getContent());
                System.out.println();
            }else {
                System.out.println("[error]: File doesn't open yet,please open first！");
                return false;
            }
        }
        return true;
    }

    @Override
    public Boolean write(String filePath) {
        //判断是否存在
        FCB fcb = DIR.pathResolve(filePath);
        if(Objects.isNull(fcb)){
            System.out.println("[error]: File doesn't exits");
            return false;
        }else if(fcb.getType().equals('D')){
            //type D 不是普通文件
            System.out.println("[error]: Cannot write directory");
            return false;
        }else {
            //type N 普通文件
            //判断文件权限
            int permission = fileService.checkPermission(fcb);
            if(permission == 0){
                System.out.println("[error]: Invalid permission");
                return false;
            }else if(permission == 4){
                System.out.println("[error]: FIle can only be read");
                return false;
            }else {
                //可写
                //判断是否在openFileList中
                String fill_path = DIR.pwd(fcb);
                List<Open> openList = Storage.getInstance().getOpenFileList();
                Open toWriteFile = null;
                for (Open open : openList) {
                    if(open.getFilePath().equals(fill_path)){
                        toWriteFile = open;
                    }
                }
                if(Objects.nonNull(toWriteFile)){
                    StringBuilder content = new StringBuilder();
                    System.out.println("Write in (Use ./ to exit and save):");
                    //获取用户输入 输入$$结束
                    while (true){
                        String nextLine = scanner.nextLine();
                        if(nextLine.endsWith("./")){
                            content.append(nextLine,0,nextLine.length()-2);
                            break;
                        }else {
                            content.append(nextLine);
                            content.append("\n");
                        }
                    }
                    String choice = null;
                    if(fcb.getIndexNode().getSize() == 0){
                        //空文件 默认覆盖
                        choice = "1";
                    }else {
                        //有内容 让用户选择写入模式
                        while (true){
                            System.out.println("Do you want to rewrite file(1) or continue write(2):");
                            choice = scanner.nextLine();
                            if(choice.equals("1") || choice.equals("2")){
                                break;
                            }
                        }
                    }
                    FAT[] fats = Storage.getInstance().getFat();
                    int size = content.toString().toCharArray().length;
                    if(choice.equals("1")){
                        //覆盖写入
                        //1.如果不是空文件 则清空之前占据的盘块
                        if(fcb.getIndexNode().getSize() != 0){
                            DISK_DATABASE.freeFile(fcb);
                            fcb.getFather().getIndexNode().subFcbNum();
                        }
                        //2.重新写入
                        int first = DISK_DATABASE.writeToDisk(content.toString());
                        //3.将文件指向第一块
                        fcb.getIndexNode().setFirst_block(first);
                        //4.修改索引结点大小
                        fcb.getIndexNode().setSize(size);
                        //修改父目录项 以及一直递归修改父目录的大小
                        DIR.updateSize(fcb,true,-1);
                    }else {
                        //追加写入
                        //1.从第一块往下找  直到-1的块的块号
                        FAT temp = fats[fcb.getIndexNode().getFirst_block()];
                        while (temp.getNextId() != -1){
                            temp = fats[temp.getNextId()];
                        }
                        //2.写入要追加的内容
                        content.insert(0,'\n');
                        int append_begin = DISK_DATABASE.writeToDisk(content.toString());
                        //3.修改最后一块指向新的内容
                        temp.setNextId(append_begin);
                        //4.修改索引结点大小 加上原来的
                        int size_origin = fcb.getIndexNode().getSize();
                        fcb.getIndexNode().setSize(size + size_origin);
                        //修改父目录项 以及一直递归修改父目录的大小
                        DIR.updateSize(fcb,true,size);
                    }
                    System.out.println("[success]: Completed！");
                    return true;
                }else {
                    System.out.println("[error]: File doesn't open yet,please open first！");
                    return false;
                }
            }
        }
    }

    @Override
    public Boolean close(String filePath) {
        //判断是否存在
        FCB fcb = DIR.pathResolve(filePath);
        if(Objects.isNull(fcb)){
            System.out.println("[error]: FIle doesn't exits");
            return false;
        }else if(fcb.getType().equals('D')){
            //type D 不是普通文件
            System.out.println("[error]: Directory can't be closed");
            return false;
        }else {
            //type N 普通文件
            //判断是否在openFileList中
            String fill_path = DIR.pwd(fcb);
            List<Open> openList = Storage.getInstance().getOpenFileList();
            for (Open open : openList) {
                if(open.getFilePath().equals(fill_path)){
                    //修改fcb的updateTime
                    fcb.getIndexNode().setUpdateTime(new Date());
                    //从openFileList中移除
                    openList.remove(open);
                    System.out.println("[success]: Closed！");
                    return true;

                }
            }
            System.out.println("[error]: File doesn't open yet！");
            return false;
        }
    }

    @Override
    public Boolean delete(String filePath) {
        //判断是否存在
        FCB fcb = DIR.pathResolve(filePath);
        if(Objects.isNull(fcb)){
            System.out.println("[error]: File doesn't exits");
            return false;
        }
        //判断权限 需要对文件夹具有rwx权限 对文件具有rw权限
        int per_father = fileService.checkPermission(fcb.getFather());
        int permission = fileService.checkPermission(fcb);
        if(!(per_father == 7 && (permission == 7 || permission == 6))){
            System.out.println("[error]: Invalid permission");
            return false;
        }
        //判断是否打开 打开要先关闭
        String fill_path = DIR.pwd(fcb);
        List<Open> openList = Storage.getInstance().getOpenFileList();
        Open toWriteFile = null;
        for (Open open : openList) {
            if(open.getFilePath().equals(fill_path)){
                toWriteFile = open;
            }
        }
        if(Objects.nonNull(toWriteFile)){
            System.out.println("[error]: File opened close file first");
            return false;
        }
        //重复确认
        String choice = null;
        while (true){
            System.out.println("Confirm delete file?（Y/N）");
            choice = scanner.nextLine();
            if(choice.equals("Y")) break;
            if(choice.equals("N")) {
                System.out.println("[success]: Cancel delete！");
                return false;
            }
        }
        //空文件判断
        if(fcb.getIndexNode().getSize() != 0 || fcb.getIndexNode().getFcbNum() != 0){
            if(fcb.getType().equals('D')){
                //type D 目录
                //diskService.freeDir(fcb);
                System.out.println("[error]: File isn't empty cannot delete,confirm delete?[Y/N]");
                String choice2=null;
                choice2=scanner.nextLine();
                if(choice.equals("Y"))
                {
                    //从FCB集合中去除 修改父目录文件项 修改父目录儿子结点
                    Disk.getINSTANCE().getFcbList().remove(fcb);
                    fcb.getFather().getIndexNode().subFcbNum();
                    fcb.getFather().getChildren().remove(fcb);
                    //递归修改父目录文件大小
                    DIR.updateSize(fcb,false,-1);
                    System.out.println("[success]: Deleted");
                    return true;
                }
                if(choice.equals("N")) {
                    System.out.println("[success]: Cancel delete！");
                }
                return false;
            }else {
                //清空磁盘
                DISK_DATABASE.freeFile(fcb);
            }
        }
        //如果是空目录 不允许是当前目录
        if(fcb == Storage.getInstance().getCurDir()){
            System.out.println("[error]: Cannot delete current directory!");
        }
        //从FCB集合中去除 修改父目录文件项 修改父目录儿子结点
        Disk.getINSTANCE().getFcbList().remove(fcb);
        fcb.getFather().getIndexNode().subFcbNum();
        fcb.getFather().getChildren().remove(fcb);
        //递归修改父目录文件大小
        DIR.updateSize(fcb,false,-1);
        System.out.println("[success]: Deleted");
        return true;
    }
    @Override
    public int checkPermission(FCB fcb) {
        int permission = 0;
        //查看是否是创建者
        String per = null;
        if(Storage.getInstance().getCurUser().getUserName().equals(fcb.getIndexNode().getCreator())){
            //前三位
            per = fcb.getIndexNode().getPermission().substring(0,3);
        }else {
            //后三位
            per = fcb.getIndexNode().getPermission().substring(3);
        }
        char[] chars = per.toCharArray();
        for (char c : chars) {
            if(c == 'r'){
                permission += Set.READ;
            }else if(c == 'w'){
                permission += Set.WRITE;
            }else if(c == 'x'){
                permission += Set.EXECUTION;
            }
        }
        return permission;
    }

    @Override
    public Boolean rename(String filePath, String newName) {
        //判断是否存在
        FCB fcb = DIR.pathResolve(filePath);
        if(Objects.isNull(fcb)){
            System.out.println("[error]: File doesn't exits");
            return false;
        }
        //判断文件权限
        int permission = fileService.checkPermission(fcb);
        if(permission == 0 || permission == 4){
            System.out.println("[error]: Invalid permission");
            return false;
        }
        //如果是普通文件 判断是否打开
        if(fcb.getType().equals('N')){
            String fill_path = DIR.pwd(fcb);
            List<Open> openList = Storage.getInstance().getOpenFileList();
            Open toWriteFile = null;
            for (Open open : openList) {
                if(open.getFilePath().equals(fill_path)){
                    toWriteFile = open;
                }
            }
            if(Objects.nonNull(toWriteFile)){
                System.out.println("[error]: File opening please close the file first！");
                return false;
            }
        }
        //判断是否重名
        //判断重复
        newName = newName.trim(); //去除首尾空格
        List<FCB> children = Storage.getInstance().getCurDir().getChildren();
        for (FCB child : children) {
            if(child.getFileName().equals(newName)){
                System.out.println("[error]: File name repeat please rename");
                return false;
            }
        }
        //进行重命名
        fcb.setFileName(newName);
        System.out.println("[success]: Modified！");
        return true;
    }
}
