public interface DiskDatabase {
    Boolean freeDir(FCB fcb);
    Boolean freeFile(FCB fcb);
    int writeToDisk(String content);
    int find_empty();

}