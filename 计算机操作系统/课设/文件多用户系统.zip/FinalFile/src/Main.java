import java.util.Scanner; // 导入Scanner类

public class Main {
    // 初始化数据库和服务实例
    private static final Data DATA_DATABASE = new DataImplement();
    private static final UserDatabase USER_DATABASE = new UserDatabaseImplement();
    private static final FileService fileService = new FileServiceImplement();
    private static final Dir DIR = new DirImplement();
    private static final Scanner scanner = new Scanner(System.in); // 创建Scanner对象用于输入

    public static void main(String[] args) {
        // 加载磁盘数据
        Boolean flag = DATA_DATABASE.loadData(Set.Path);
        if (!flag) {
            // 加载失败请求初始化新的
            System.out.println("Init a new disk?（Y/N）");
            if (scanner.nextLine().equalsIgnoreCase("Y")) {
                DATA_DATABASE.init();
            } else {
                System.exit(0);
            }
        }
        Boolean login = false;
        while (true) {
            System.out.println("Please Choose");
            System.out.println("1.Login");
            System.out.println("2.Register");
            System.out.println("3.Exit");
            String nextLine = scanner.nextLine();
            String[] inputs = Space.inputResolve(nextLine);
            switch (inputs[0]) {
                case "1":
                    System.out.print("Username: ");
                    String username = scanner.nextLine();
                    System.out.print("Password: ");
                    String pwd = scanner.nextLine();
                    login = USER_DATABASE.login(username, pwd);
                    if (login) {
                        System.out.println("Login");
                        Boolean logout = false;
                        while (!logout) {
                            DIR.showPath();
                            String nextLine2 = scanner.nextLine();
                            String[] inputs2 = Space.inputResolve(nextLine2);
                            switch (inputs2[0]) {
                                case "exit":
                                    logout = USER_DATABASE.logout();
                                    break;
                                case "mkdir":
                                    if (inputs2.length == 1) {
                                        System.out.println("mkdir [dirName]");
                                        break;
                                    }
                                    System.out.println("Insert permission：r:read w:write x:execute");
                                    String permission2 = scanner.nextLine();
                                    while (permission2.length() != 3) {
                                        System.out.println("Insert permission：r:read w:write x:execute");
                                        permission2 = scanner.nextLine();
                                    }
                                    DIR.mkdir(inputs2[1], permission2);
                                    break;
                                case "rmdir":
                                    if (inputs2.length == 1) {
                                        System.out.println("rmdir [dirName]");
                                        break;
                                    }
                                    DIR.rmdir(inputs2[1]);
                                    break;
                                case "dir":
                                    DIR.dir();
                                    break;
                                case "ll":
                                    DIR.dir();
                                    break;
                                case "pwd":
                                    String path = DIR.pwd(Storage.getInstance().getCurDir());
                                    System.out.print(path);
                                    break;
                                case "touch":
                                    if (inputs2.length == 1) {
                                        System.out.println("touch [fileName]");
                                        break;
                                    }
                                    System.out.println("Insert permission：r:read w:write x:execute");
                                    String permission = scanner.nextLine();
                                    while (permission.length() != 3){
                                        System.out.println("Insert permission：r:read w:write x:execute");
                                        permission = scanner.nextLine();
                                    }
                                    fileService.create(inputs2[1], permission);
                                    break;
                                case "cd":
                                    if (inputs2.length == 1) {
                                        System.out.println("cd [fileName]");
                                        break;
                                    }
                                    DIR.cd(inputs2[1]);
                                    break;
                                case "vim":
                                    if (inputs2.length == 1) {
                                        System.out.println("vim [fileName]");
                                        break;
                                    }
                                    fileService.open(inputs2[1]);
                                    break;
                                case "show":
                                    fileService.show_open();
                                    break;
                                case "close":
                                    if (inputs2.length == 1) {
                                        System.out.println("close [fileName]");
                                        break;
                                    }
                                    fileService.close(inputs2[1]);
                                    break;
                                case "cat":
                                    if (inputs2.length == 1) {
                                        System.out.println("cat [fileName]");
                                        break;
                                    }
                                    fileService.read(inputs2[1]);
                                    break;
                                case "write":
                                    if (inputs2.length == 1) {
                                        System.out.println("write [fileName]");
                                        break;
                                    }
                                    fileService.write(inputs2[1]);
                                    break;
                                case "bitmap":
                                    DIR.bitmap();
                                    break;
                                case "rm":
                                    if (inputs2.length == 1) {
                                        System.out.println("rm [fileName]");
                                        break;
                                    }
                                    fileService.delete(inputs2[1]);
                                    break;
                                case "rn":
                                    if (inputs2.length < 3) {
                                        System.out.println("rn [filePath] [newName]");
                                        break;
                                    }
                                    fileService.rename(inputs2[1], inputs2[2]);
                                    break;
                                case "ls":
                                    DIR.ls();
                                    break;
                                case "time":
                                    java.time.LocalTime currentTime = java.time.LocalTime.now();
                                    System.out.println("Current Time: " + currentTime);
                                    break;
                                case "who":
                                    Storage instance= Storage.getInstance();
                                    System.out.println("Current User: " + instance.getUserMap().get(username));
                                    break;
                                case "storage":
                                    Storage storage= Storage.getInstance();
                                    DIR.displayRemainingSpace();
                                    break;
                                case "help":
                                    new View().help();
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                    break;
                case "2":
                    System.out.print("Username: ");
                    String username2 = scanner.nextLine();
                    System.out.print("Password: ");
                    String pwd2 = scanner.nextLine();
                    USER_DATABASE.register(username2, pwd2);
                    break;
                case "3":
                    System.exit(0);
                    break;
                default:
                    new View().help();
                    break;
            }
        }
    }
}
