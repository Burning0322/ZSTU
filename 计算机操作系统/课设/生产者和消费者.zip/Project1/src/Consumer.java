import java.util.List;

class Consumer implements Runnable {
    private static final int TIMES = 3; //生产者消费者的迭代次数即线程个数
    private final List<Integer> list;     // 存储商品列表

    // 构造消费者
    Consumer(List<Integer> list) {
        this.list = list;
    }

    @Override
    public void run() {
        // 消费者进程开始
        for (int i = 0; i < TIMES; i++) {
//synchronized关键字保证其修饰的代码块任意时刻只有一个线程访问,给共享缓冲区加锁
            synchronized (list) {
                // 缓冲区处于空状态
                while (list.isEmpty()) {
                    try {
                        System.out.println("消费者：" + Thread.currentThread().getName() + "\t仓库已空，进入阻塞状态");
                        try {
                            list.wait();    // 进程进入等待状态
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        System.out.println("消费者：" + Thread.currentThread().getName() + "\t被唤醒，退出阻塞状态");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                // 缓冲区非空，消费者购买商品
                Integer removed = list.remove(0);
                System.out.println("消费者：" + Thread.currentThread().getName() + "\t购买的商品编号为：R" + removed);
                Space.showList(list);     // 显示缓冲区数据
                list.notifyAll();              // 释放阻塞进程
                try {
                    Thread.sleep(500);    // 线程休眠半秒以防速度过快
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        // 消费者的进程结束
        System.out.println("消费者：" + Thread.currentThread().getName() + "\t消费结束，进程结束！");
    }
}