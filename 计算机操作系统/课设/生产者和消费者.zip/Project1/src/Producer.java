import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

class Producer implements Runnable {
    private static final ThreadLocalRandom RANDOM = ThreadLocalRandom.current();  // 多线程环境下生成随机线程
    private static final int TIMES = 3; // 生产者消费者的迭代次数即线程个数
    private final List<Integer> list;   // 存储列表
    private final int MAX_SIZE;         // 缓冲区大小

    // 构造生产者，提供存储列表和缓冲区大小
    Producer(List<Integer> list, int size) {
        this.list = list;
        this.MAX_SIZE = size;
    }

    @Override
    public void run() {
        // 生产者进程开始
        for (int i = 0; i < TIMES; i++) {
        //synchronized关键字保证其修饰的代码块任意时刻只有一个线程访问,给共享缓冲区加锁
            synchronized (list) {
                while (list.size() == this.MAX_SIZE) { // 缓冲区满
                    try {
                        System.out.println("生产者：" + Thread.currentThread().getName() + "\t仓库已达最大容量，进入阻塞状态");
                        try {
                            list.wait(); // 线程阻塞
                        } catch (Exception e) {
                            // TODO: handle exception
                            e.printStackTrace();
                        }
                        System.out.println("生产者：" + Thread.currentThread().getName() + "\t被唤醒，退出阻塞状态");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                // 缓冲区没满，生产者生产
                int number = RANDOM.nextInt(8000); // 随机生成产品编号
                System.out.println("生产者：" + Thread.currentThread().getName() + "\t生产的产品编号为：R" + number);
                list.add(number);  // 将商品添加到共享区
                Space.showList(list);
                list.notifyAll();  // 释放阻塞线程
                try {
                    Thread.sleep(500);   // 线程休眠半秒以防速度过快
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        // 生产者的进程结束
        System.out.println("生产者：" + Thread.currentThread().getName() + "\t停止生产，进程结束！");
    }
}